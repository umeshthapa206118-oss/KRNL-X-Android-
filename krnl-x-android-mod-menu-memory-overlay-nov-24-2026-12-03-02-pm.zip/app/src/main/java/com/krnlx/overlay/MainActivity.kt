package com.krnlx.overlay

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.krnlx.overlay.ui.components.ArenaSimulationCanvas
import com.krnlx.overlay.ui.components.FloatingBubble
import com.krnlx.overlay.ui.components.FpsHudBar
import com.krnlx.overlay.ui.components.ModMenuOverlay
import com.krnlx.overlay.ui.components.VipLoginScreen
import com.krnlx.overlay.ui.theme.KrnlColors
import com.krnlx.overlay.ui.theme.KrnlXOverlayTheme
import com.krnlx.overlay.viewmodel.OverlayViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            KrnlXOverlayTheme {
                KrnlXOverlayApp()
            }
        }
    }
}

@Composable
fun KrnlXOverlayApp(viewModel: OverlayViewModel = viewModel()) {
    val unlocked by viewModel.unlocked.collectAsState()
    val licenseKey by viewModel.licenseKey.collectAsState()
    val menuOpen by viewModel.menuOpen.collectAsState()
    val config by viewModel.config.collectAsState()
    val metrics by viewModel.metrics.collectAsState()
    val engineReady by viewModel.overlayEngineReady.collectAsState()
    val isRunningCheck by viewModel.isRunningCheck.collectAsState()
    val logs by viewModel.logs.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(KrnlColors.VoidBg),
    ) {
        // Full-screen interactive ESP / FOV / Crosshair simulation viewport
        ArenaSimulationCanvas(
            config = config,
            engineReady = engineReady,
        )

        // Optional stealth viewport border indicator
        if (unlocked && config.stealthBorderSimulation) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(2.dp, KrnlColors.Crimson.copy(alpha = 0.4f)),
            )
        }

        // Top Live FPS & Ping HUD
        FpsHudBar(
            metrics = metrics,
            config = config,
            engineReady = engineReady,
            modifier = Modifier.align(Alignment.TopStart),
        )

        if (!unlocked) {
            VipLoginScreen(
                onGenerateKey = viewModel::generateDemoKey,
                onVerifyKey = viewModel::verifyAndUnlock,
            )
        } else {
            FloatingBubble(
                menuOpen = menuOpen,
                engineReady = engineReady,
                onToggleMenu = viewModel::toggleMenu,
            )

            if (menuOpen) {
                ModMenuOverlay(
                    licenseKey = licenseKey,
                    config = config,
                    engineReady = engineReady,
                    isRunningCheck = isRunningCheck,
                    logs = logs,
                    onUpdateConfig = viewModel::updateConfig,
                    onResetConfig = viewModel::resetConfig,
                    onMinimize = viewModel::minimizeMenu,
                    onRunSimulationCheck = viewModel::runOverlaySimulationCheck,
                    onClearLogs = viewModel::clearLogs,
                )
            }
        }
    }
}
