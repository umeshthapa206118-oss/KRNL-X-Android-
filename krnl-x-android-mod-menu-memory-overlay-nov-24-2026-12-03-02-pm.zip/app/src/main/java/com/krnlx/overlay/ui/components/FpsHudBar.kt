package com.krnlx.overlay.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.krnlx.overlay.model.FpsMetrics
import com.krnlx.overlay.model.OverlayConfig
import com.krnlx.overlay.ui.theme.KrnlColors

@Composable
fun FpsHudBar(
    metrics: FpsMetrics,
    config: OverlayConfig,
    engineReady: Boolean,
    modifier: Modifier = Modifier,
) {
    val borderColor = if (config.fpsBoosterEnabled) {
        KrnlColors.Cyan.copy(alpha = 0.45f)
    } else {
        KrnlColors.CardBorder
    }

    Row(
        modifier = modifier
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(KrnlColors.GlassSurface)
            .border(1.dp, borderColor, RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = "${metrics.fps} FPS",
            color = if (config.fpsBoosterEnabled) KrnlColors.Cyan else KrnlColors.TextPrimary,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
        )
        Text(
            text = "·",
            color = KrnlColors.TextMuted,
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
        )
        Text(
            text = "${metrics.pingMs} ms",
            color = if (config.antiLagHudEnabled) KrnlColors.Emerald else KrnlColors.Amber,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp,
        )
        Text(
            text = "·",
            color = KrnlColors.TextMuted,
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
        )
        Text(
            text = "${metrics.frameTimeMs} ms/f",
            color = KrnlColors.TextSecondary,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
        )
        if (engineReady) {
            Text(
                text = "·",
                color = KrnlColors.TextMuted,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
            )
            Text(
                text = "DEMO READY",
                color = KrnlColors.Emerald,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                fontSize = 11.sp,
            )
        }
    }
}
