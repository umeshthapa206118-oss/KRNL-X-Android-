package com.krnlx.overlay.model

enum class AimBone(val label: String) {
    HEAD("HEAD"),
    NECK("NECK"),
    CHEST("CHEST"),
}

enum class CrosshairStyle(val label: String) {
    PRO_T("Pro T"),
    CYBER_DOT("Cyber Dot"),
    DYNAMIC_X("Dynamic X"),
}

enum class CrosshairColor(val label: String, val hex: Long) {
    CYAN("CYAN", 0xFF00F0FF),
    CRIMSON("CRIMSON", 0xFFFF1E42),
    EMERALD("EMERALD", 0xFF10B981),
}

enum class MenuTab(val title: String) {
    ESP("ESP Visuals"),
    AIM("Aim & FOV"),
    SYSTEM("120 FPS"),
}

data class OverlayConfig(
    val espEnabled: Boolean = true,
    val espBoxes: Boolean = true,
    val espSnaplines: Boolean = true,
    val espHealthBar: Boolean = true,
    val espSkeleton: Boolean = true,
    val aimSimulationEnabled: Boolean = true,
    val aimFovRadiusPx: Float = 160f,
    val aimSmoothness: Float = 6.5f,
    val aimBone: AimBone = AimBone.HEAD,
    val crosshairEnabled: Boolean = true,
    val crosshairStyle: CrosshairStyle = CrosshairStyle.PRO_T,
    val crosshairColor: CrosshairColor = CrosshairColor.CYAN,
    val fpsBoosterEnabled: Boolean = true,
    val antiLagHudEnabled: Boolean = true,
    val stealthBorderSimulation: Boolean = false,
)

data class FpsMetrics(
    val fps: Int = 120,
    val pingMs: Int = 14,
    val frameTimeMs: Float = 8.3f,
)

enum class LogLevel {
    CMD,
    INFO,
    SUCCESS,
    WARN,
}

data class ConsoleLogEntry(
    val id: Long,
    val timestamp: String,
    val level: LogLevel,
    val message: String,
)

data class SimEnemy(
    val id: Int,
    val name: String,
    val baseX: Float,
    val depth: Float,
    val speed: Float,
    val phase: Float,
    val hp: Int,
    val maxHp: Int = 100,
)
