package com.krnlx.overlay.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GpsFixed
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.krnlx.overlay.ui.theme.KrnlColors
import kotlin.math.roundToInt

@Composable
fun FloatingBubble(
    menuOpen: Boolean,
    engineReady: Boolean,
    onToggleMenu: () -> Unit,
) {
    val density = LocalDensity.current
    val configuration = LocalConfiguration.current
    val maxWidthPx = with(density) { (configuration.screenWidthDp.dp - 68.dp).toPx().coerceAtLeast(24f) }
    val maxHeightPx = with(density) { (configuration.screenHeightDp.dp - 88.dp).toPx().coerceAtLeast(24f) }
    val initialX = with(density) { 16.dp.toPx() }
    val initialY = with(density) { 96.dp.toPx() }

    var offsetX by remember { mutableFloatStateOf(initialX) }
    var offsetY by remember { mutableFloatStateOf(initialY) }

    val borderColor = when {
        menuOpen -> KrnlColors.Crimson
        engineReady -> KrnlColors.Cyan
        else -> KrnlColors.CardBorder
    }

    Box(
        modifier = Modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .size(56.dp)
            .shadow(14.dp, RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(KrnlColors.GlassSurface)
            .border(1.5.dp, borderColor, RoundedCornerShape(16.dp))
            .pointerInput(maxWidthPx, maxHeightPx) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    offsetX = (offsetX + dragAmount.x).coerceIn(12f, maxWidthPx)
                    offsetY = (offsetY + dragAmount.y).coerceIn(24f, maxHeightPx)
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onToggleMenu() },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(
                imageVector = if (engineReady) Icons.Rounded.Shield else Icons.Rounded.GpsFixed,
                contentDescription = "Toggle KRNL-X Overlay",
                tint = if (menuOpen) KrnlColors.Crimson else KrnlColors.Cyan,
                modifier = Modifier.size(22.dp),
            )
            Text(
                text = "KX",
                color = if (menuOpen) KrnlColors.CrimsonSoft else KrnlColors.Cyan,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp,
            )
        }
    }
}
