package com.krnlx.overlay.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.krnlx.overlay.model.AimBone
import com.krnlx.overlay.model.ConsoleLogEntry
import com.krnlx.overlay.model.CrosshairColor
import com.krnlx.overlay.model.CrosshairStyle
import com.krnlx.overlay.model.FpsMetrics
import com.krnlx.overlay.model.LogLevel
import com.krnlx.overlay.model.OverlayConfig
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class OverlayViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("krnlx_overlay_prefs", Context.MODE_PRIVATE)

    private val _unlocked = MutableStateFlow(false)
    val unlocked: StateFlow<Boolean> = _unlocked.asStateFlow()

    private val _licenseKey = MutableStateFlow("")
    val licenseKey: StateFlow<String> = _licenseKey.asStateFlow()

    private val _menuOpen = MutableStateFlow(true)
    val menuOpen: StateFlow<Boolean> = _menuOpen.asStateFlow()

    private val _config = MutableStateFlow(loadConfig())
    val config: StateFlow<OverlayConfig> = _config.asStateFlow()

    private val _metrics = MutableStateFlow(FpsMetrics())
    val metrics: StateFlow<FpsMetrics> = _metrics.asStateFlow()

    private val _overlayEngineReady = MutableStateFlow(false)
    val overlayEngineReady: StateFlow<Boolean> = _overlayEngineReady.asStateFlow()

    private val _isRunningCheck = MutableStateFlow(false)
    val isRunningCheck: StateFlow<Boolean> = _isRunningCheck.asStateFlow()

    private val _logs = MutableStateFlow<List<ConsoleLogEntry>>(emptyList())
    val logs: StateFlow<List<ConsoleLogEntry>> = _logs.asStateFlow()

    private var diagnosticJob: Job? = null
    private var logCounter = 0L

    init {
        startFpsTelemetrySimulation()
    }

    private fun startFpsTelemetrySimulation() {
        viewModelScope.launch {
            while (isActive) {
                val cfg = _config.value
                val fps = if (cfg.fpsBoosterEnabled) {
                    Random.nextInt(117, 121)
                } else {
                    Random.nextInt(56, 61)
                }
                val ping = when {
                    cfg.fpsBoosterEnabled && cfg.antiLagHudEnabled -> Random.nextInt(12, 17)
                    cfg.antiLagHudEnabled -> Random.nextInt(22, 29)
                    cfg.fpsBoosterEnabled -> Random.nextInt(42, 56)
                    else -> Random.nextInt(60, 78)
                }
                val frameMs = ((1000f / fps) * 10f).toInt() / 10f
                _metrics.value = FpsMetrics(fps = fps, pingMs = ping, frameTimeMs = frameMs)
                delay(650L)
            }
        }
    }

    fun generateDemoKey(): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val token = buildString {
            repeat(4) {
                append(alphabet[Random.nextInt(alphabet.length)])
            }
        }
        return "KRNL-VIP-$token-ARM64"
    }

    fun verifyAndUnlock(rawKey: String): String? {
        val cleaned = rawKey.trim().uppercase(Locale.US)
        if (cleaned.isEmpty()) {
            return "Enter a VIP simulation key or tap GET KEY to auto-fill."
        }
        val pattern = Regex("^KRNL-VIP-[A-Z0-9]{4}-ARM64$")
        if (!pattern.matches(cleaned) && cleaned != "DEMO" && cleaned != "VIP-2026") {
            return "Invalid key format. Expected KRNL-VIP-XXXX-ARM64."
        }
        _licenseKey.value = cleaned
        _unlocked.value = true
        _menuOpen.value = true
        return null
    }

    fun toggleMenu() {
        _menuOpen.update { !it }
    }

    fun minimizeMenu() {
        _menuOpen.value = false
    }

    fun updateConfig(transform: (OverlayConfig) -> OverlayConfig) {
        _config.update { current ->
            val next = transform(current)
            saveConfig(next)
            next
        }
    }

    fun resetConfig() {
        val defaults = OverlayConfig()
        _config.value = defaults
        saveConfig(defaults)
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }

    /**
     * Simulates local Compose UI overlay & canvas pipeline initialization only.
     * Does not access external processes, game memory, or system hooks.
     */
    fun runOverlaySimulationCheck() {
        if (_isRunningCheck.value) return
        diagnosticJob?.cancel()
        _isRunningCheck.value = true
        _overlayEngineReady.value = false
        _logs.value = emptyList()

        val steps = listOf(
            40L to (LogLevel.CMD to "overlay-sim --verify-pipeline --render compose-canvas"),
            280L to (LogLevel.INFO to "[*] Initializing Jetpack Compose Hardware Layer (Sandbox)"),
            580L to (LogLevel.INFO to "[*] Binding ESP vector renderer & bounding box math"),
            900L to (LogLevel.INFO to "[*] Calibrating simulated FOV circle & crosshair reticle"),
            1220L to (LogLevel.INFO to "[*] Syncing 120 FPS frame-pacing HUD telemetry loop"),
            1540L to (LogLevel.SUCCESS to "SUCCESS! Visual overlay simulation active (local demo mode)."),
        )

        diagnosticJob = viewModelScope.launch {
            var elapsed = 0L
            for ((targetMs, entry) in steps) {
                delay(targetMs - elapsed)
                elapsed = targetMs
                appendLog(entry.first, entry.second)
            }
            _isRunningCheck.value = false
            _overlayEngineReady.value = true
        }
    }

    private fun appendLog(level: LogLevel, message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val item = ConsoleLogEntry(
            id = ++logCounter,
            timestamp = time,
            level = level,
            message = message,
        )
        _logs.update { it + item }
    }

    private fun loadConfig(): OverlayConfig {
        return OverlayConfig(
            espEnabled = prefs.getBoolean("espEnabled", true),
            espBoxes = prefs.getBoolean("espBoxes", true),
            espSnaplines = prefs.getBoolean("espSnaplines", true),
            espHealthBar = prefs.getBoolean("espHealthBar", true),
            espSkeleton = prefs.getBoolean("espSkeleton", true),
            aimSimulationEnabled = prefs.getBoolean("aimSimulationEnabled", true),
            aimFovRadiusPx = prefs.getFloat("aimFovRadiusPx", 160f),
            aimSmoothness = prefs.getFloat("aimSmoothness", 6.5f),
            aimBone = AimBone.entries.getOrElse(prefs.getInt("aimBone", 0)) { AimBone.HEAD },
            crosshairEnabled = prefs.getBoolean("crosshairEnabled", true),
            crosshairStyle = CrosshairStyle.entries.getOrElse(prefs.getInt("crosshairStyle", 0)) { CrosshairStyle.PRO_T },
            crosshairColor = CrosshairColor.entries.getOrElse(prefs.getInt("crosshairColor", 0)) { CrosshairColor.CYAN },
            fpsBoosterEnabled = prefs.getBoolean("fpsBoosterEnabled", true),
            antiLagHudEnabled = prefs.getBoolean("antiLagHudEnabled", true),
            stealthBorderSimulation = prefs.getBoolean("stealthBorderSimulation", false),
        )
    }

    private fun saveConfig(cfg: OverlayConfig) {
        prefs.edit()
            .putBoolean("espEnabled", cfg.espEnabled)
            .putBoolean("espBoxes", cfg.espBoxes)
            .putBoolean("espSnaplines", cfg.espSnaplines)
            .putBoolean("espHealthBar", cfg.espHealthBar)
            .putBoolean("espSkeleton", cfg.espSkeleton)
            .putBoolean("aimSimulationEnabled", cfg.aimSimulationEnabled)
            .putFloat("aimFovRadiusPx", cfg.aimFovRadiusPx)
            .putFloat("aimSmoothness", cfg.aimSmoothness)
            .putInt("aimBone", cfg.aimBone.ordinal)
            .putBoolean("crosshairEnabled", cfg.crosshairEnabled)
            .putInt("crosshairStyle", cfg.crosshairStyle.ordinal)
            .putInt("crosshairColor", cfg.crosshairColor.ordinal)
            .putBoolean("fpsBoosterEnabled", cfg.fpsBoosterEnabled)
            .putBoolean("antiLagHudEnabled", cfg.antiLagHudEnabled)
            .putBoolean("stealthBorderSimulation", cfg.stealthBorderSimulation)
            .apply()
    }
}
