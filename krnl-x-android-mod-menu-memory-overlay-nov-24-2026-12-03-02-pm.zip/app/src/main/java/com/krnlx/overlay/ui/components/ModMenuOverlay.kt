package com.krnlx.overlay.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.material.icons.rounded.GpsFixed
import androidx.compose.material.icons.rounded.Minimize
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.krnlx.overlay.model.AimBone
import com.krnlx.overlay.model.ConsoleLogEntry
import com.krnlx.overlay.model.CrosshairColor
import com.krnlx.overlay.model.CrosshairStyle
import com.krnlx.overlay.model.LogLevel
import com.krnlx.overlay.model.MenuTab
import com.krnlx.overlay.model.OverlayConfig
import com.krnlx.overlay.ui.theme.KrnlColors
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun ModMenuOverlay(
    licenseKey: String,
    config: OverlayConfig,
    engineReady: Boolean,
    isRunningCheck: Boolean,
    logs: List<ConsoleLogEntry>,
    onUpdateConfig: ((OverlayConfig) -> OverlayConfig) -> Unit,
    onResetConfig: () -> Unit,
    onMinimize: () -> Unit,
    onRunSimulationCheck: () -> Unit,
    onClearLogs: () -> Unit,
) {
    var activeTab by remember { mutableStateOf(MenuTab.ESP) }
    var dragX by remember { mutableFloatStateOf(0f) }
    var dragY by remember { mutableFloatStateOf(0f) }

    val density = LocalDensity.current
    val configuration = LocalConfiguration.current
    val maxDragX = with(density) { (configuration.screenWidthDp.dp * 0.25f).toPx().coerceAtLeast(32f) }
    val maxDragY = with(density) { (configuration.screenHeightDp.dp * 0.22f).toPx().coerceAtLeast(32f) }

    val listState = rememberLazyListState()
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.lastIndex)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .offset { IntOffset(dragX.roundToInt(), dragY.roundToInt()) }
                .widthIn(max = 420.dp)
                .fillMaxWidth()
                .heightIn(max = (configuration.screenHeightDp * 0.84f).dp)
                .clip(RoundedCornerShape(18.dp))
                .background(KrnlColors.GlassSurface)
                .border(1.dp, KrnlColors.CardBorder, RoundedCornerShape(18.dp)),
        ) {
            // Top neon gradient line
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(KrnlColors.Crimson, KrnlColors.Cyan, KrnlColors.Crimson),
                        ),
                    ),
            )

            // Draggable Title Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0x08FFFFFF))
                    .pointerInput(maxDragX, maxDragY) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            dragX = (dragX + dragAmount.x).coerceIn(-maxDragX, maxDragX)
                            dragY = (dragY + dragAmount.y).coerceIn(-maxDragY, maxDragY)
                        }
                    }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.DragHandle,
                        contentDescription = null,
                        tint = KrnlColors.TextMuted,
                        modifier = Modifier.size(18.dp),
                    )
                    Column {
                        Text(
                            text = "KRNL-X MOD MENU",
                            color = KrnlColors.TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = "$licenseKey · ${if (engineReady) "SANDBOX ACTIVE" else "UI DEMO"}",
                            color = KrnlColors.TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(
                        onClick = onResetConfig,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(KrnlColors.CardSurface)
                            .border(1.dp, KrnlColors.CardBorder, RoundedCornerShape(10.dp)),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "Reset Config",
                            tint = KrnlColors.TextSecondary,
                            modifier = Modifier.size(18.dp),
                        )
                    }

                    IconButton(
                        onClick = onMinimize,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(KrnlColors.Crimson.copy(alpha = 0.16f))
                            .border(1.dp, KrnlColors.Crimson.copy(alpha = 0.45f), RoundedCornerShape(10.dp)),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Minimize,
                            contentDescription = "Collapse to Bubble",
                            tint = KrnlColors.CrimsonSoft,
                            modifier = Modifier.size(18.dp),
                        )
                    }
                }
            }

            HorizontalDivider(color = KrnlColors.CardBorder)

            // Segmented Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xB307090D))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                MenuTabButton(
                    title = MenuTab.ESP.title,
                    icon = Icons.Rounded.Visibility,
                    selected = activeTab == MenuTab.ESP,
                    accent = KrnlColors.Cyan,
                    onClick = { activeTab = MenuTab.ESP },
                    modifier = Modifier.weight(1f),
                )
                MenuTabButton(
                    title = MenuTab.AIM.title,
                    icon = Icons.Rounded.GpsFixed,
                    selected = activeTab == MenuTab.AIM,
                    accent = KrnlColors.Crimson,
                    onClick = { activeTab = MenuTab.AIM },
                    modifier = Modifier.weight(1f),
                )
                MenuTabButton(
                    title = MenuTab.SYSTEM.title,
                    icon = Icons.Rounded.Speed,
                    selected = activeTab == MenuTab.SYSTEM,
                    accent = KrnlColors.Cyan,
                    onClick = { activeTab = MenuTab.SYSTEM },
                    modifier = Modifier.weight(1f),
                )
            }

            HorizontalDivider(color = KrnlColors.CardBorder)

            // Scrollable Feature Controls
            Column(
                modifier = Modifier
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                when (activeTab) {
                    MenuTab.ESP -> {
                        CyberToggleRow(
                            label = "Master ESP Overlay",
                            description = "Draw simulated enemy hitboxes & labels",
                            checked = config.espEnabled,
                            accent = KrnlColors.Crimson,
                            onToggle = { v -> onUpdateConfig { it.copy(espEnabled = v) } },
                        )
                        CyberToggleRow(
                            label = "2D Corner Hitboxes",
                            description = "Render glowing enemy bounding boxes",
                            checked = config.espBoxes,
                            accent = KrnlColors.Cyan,
                            onToggle = { v -> onUpdateConfig { it.copy(espBoxes = v) } },
                        )
                        CyberToggleRow(
                            label = "Player Health & Distance",
                            description = "Show dynamic HP bar, alias & distance",
                            checked = config.espHealthBar,
                            accent = KrnlColors.Cyan,
                            onToggle = { v -> onUpdateConfig { it.copy(espHealthBar = v) } },
                        )
                        CyberToggleRow(
                            label = "Snaplines & Head Skeleton",
                            description = "Draw bone axis and top-center tracers",
                            checked = config.espSnaplines && config.espSkeleton,
                            accent = KrnlColors.Cyan,
                            onToggle = { v ->
                                onUpdateConfig { it.copy(espSnaplines = v, espSkeleton = v) }
                            },
                        )
                    }

                    MenuTab.AIM -> {
                        CyberToggleRow(
                            label = "Aimbot & FOV Lock (Sim)",
                            description = "Render FOV ring & smooth target tracker",
                            checked = config.aimSimulationEnabled,
                            accent = KrnlColors.Crimson,
                            onToggle = { v -> onUpdateConfig { it.copy(aimSimulationEnabled = v) } },
                        )

                        CyberSliderCard(
                            label = "FOV Circle Radius",
                            valueText = "${config.aimFovRadiusPx.roundToInt()} px",
                            value = config.aimFovRadiusPx,
                            valueRange = 80f..360f,
                            accent = KrnlColors.Cyan,
                            onValueChange = { v ->
                                onUpdateConfig { it.copy(aimFovRadiusPx = v) }
                            },
                        )

                        CyberSliderCard(
                            label = "Smoothness Interpolation",
                            valueText = String.format(Locale.US, "%.1fx", config.aimSmoothness),
                            value = config.aimSmoothness,
                            valueRange = 1f..20f,
                            accent = KrnlColors.Crimson,
                            onValueChange = { v ->
                                onUpdateConfig { it.copy(aimSmoothness = v) }
                            },
                        )

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(KrnlColors.CardSurface)
                                .border(1.dp, KrnlColors.CardBorder, RoundedCornerShape(12.dp))
                                .padding(12.dp),
                        ) {
                            Text(
                                text = "Simulated Target Bone",
                                color = KrnlColors.TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                AimBone.entries.forEach { bone ->
                                    val selected = config.aimBone == bone
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(38.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(
                                                if (selected) KrnlColors.Crimson else KrnlColors.VoidBg,
                                            )
                                            .border(
                                                1.dp,
                                                if (selected) KrnlColors.Crimson else KrnlColors.CardBorder,
                                                RoundedCornerShape(8.dp),
                                            )
                                            .clickable {
                                                onUpdateConfig { it.copy(aimBone = bone) }
                                            },
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Text(
                                            text = bone.label,
                                            color = if (selected) Color.White else KrnlColors.TextSecondary,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                        )
                                    }
                                }
                            }
                        }

                        CyberToggleRow(
                            label = "Custom Pro Crosshair",
                            description = "Render crisp center-screen reticle",
                            checked = config.crosshairEnabled,
                            accent = KrnlColors.Cyan,
                            onToggle = { v -> onUpdateConfig { it.copy(crosshairEnabled = v) } },
                        )

                        if (config.crosshairEnabled) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(KrnlColors.CardSurface)
                                    .border(1.dp, KrnlColors.CardBorder, RoundedCornerShape(12.dp))
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    CrosshairStyle.entries.forEach { style ->
                                        val selected = config.crosshairStyle == style
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(36.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(
                                                    if (selected) KrnlColors.Cyan.copy(alpha = 0.2f) else KrnlColors.VoidBg,
                                                )
                                                .border(
                                                    1.dp,
                                                    if (selected) KrnlColors.Cyan else KrnlColors.CardBorder,
                                                    RoundedCornerShape(8.dp),
                                                )
                                                .clickable {
                                                    onUpdateConfig { it.copy(crosshairStyle = style) }
                                                },
                                            contentAlignment = Alignment.Center,
                                        ) {
                                            Text(
                                                text = style.label,
                                                color = if (selected) KrnlColors.Cyan else KrnlColors.TextSecondary,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium,
                                            )
                                        }
                                    }
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    CrosshairColor.entries.forEach { col ->
                                        val selected = config.crosshairColor == col
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(34.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(
                                                    if (selected) Color(0x26FFFFFF) else KrnlColors.VoidBg,
                                                )
                                                .border(
                                                    1.dp,
                                                    if (selected) Color(col.hex) else KrnlColors.CardBorder,
                                                    RoundedCornerShape(8.dp),
                                                )
                                                .clickable {
                                                    onUpdateConfig { it.copy(crosshairColor = col) }
                                                },
                                            contentAlignment = Alignment.Center,
                                        ) {
                                            Text(
                                                text = col.label,
                                                color = if (selected) Color(col.hex) else KrnlColors.TextSecondary,
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.SemiBold,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    MenuTab.SYSTEM -> {
                        CyberToggleRow(
                            label = "120 FPS HUD Simulation",
                            description = "Toggle 120Hz telemetry readout mode",
                            checked = config.fpsBoosterEnabled,
                            accent = KrnlColors.Cyan,
                            onToggle = { v -> onUpdateConfig { it.copy(fpsBoosterEnabled = v) } },
                        )
                        CyberToggleRow(
                            label = "Low-Latency Ping Display",
                            description = "Simulate optimized ping in top HUD",
                            checked = config.antiLagHudEnabled,
                            accent = KrnlColors.Cyan,
                            onToggle = { v -> onUpdateConfig { it.copy(antiLagHudEnabled = v) } },
                        )
                        CyberToggleRow(
                            label = "Stealth Border Highlight",
                            description = "Visual viewport frame indicator",
                            checked = config.stealthBorderSimulation,
                            accent = KrnlColors.Crimson,
                            onToggle = { v ->
                                onUpdateConfig { it.copy(stealthBorderSimulation = v) }
                            },
                        )
                    }
                }
            }

            // Bottom Overlay Pipeline Diagnostic Console
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xF206080C))
                    .border(1.dp, KrnlColors.CardBorder)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Terminal,
                            contentDescription = null,
                            tint = KrnlColors.Cyan,
                            modifier = Modifier.size(14.dp),
                        )
                        Text(
                            text = "overlay-sim · diagnostic log",
                            color = KrnlColors.TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                        )
                    }

                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable(onClick = onClearLogs)
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteOutline,
                            contentDescription = "Clear logs",
                            tint = KrnlColors.TextSecondary,
                            modifier = Modifier.size(13.dp),
                        )
                        Text(
                            text = "Clear",
                            color = KrnlColors.TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                        )
                    }
                }

                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(104.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF040508))
                        .border(1.dp, KrnlColors.CardBorder, RoundedCornerShape(10.dp))
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    if (logs.isEmpty()) {
                        item {
                            Text(
                                text = "Ready. Tap RUN OVERLAY DIAGNOSTIC to test local Compose HUD pipeline.",
                                color = KrnlColors.TextMuted,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                            )
                        }
                    } else {
                        items(logs, key = { it.id }) { entry ->
                            val msgColor = when (entry.level) {
                                LogLevel.CMD -> KrnlColors.Cyan
                                LogLevel.INFO -> KrnlColors.TextSecondary
                                LogLevel.WARN -> KrnlColors.CrimsonSoft
                                LogLevel.SUCCESS -> KrnlColors.Emerald
                            }
                            Text(
                                text = "[${entry.timestamp}] ${entry.message}",
                                color = msgColor,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                lineHeight = 15.sp,
                            )
                        }
                    }
                }

                Button(
                    onClick = onRunSimulationCheck,
                    enabled = !isRunningCheck,
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(vertical = 12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (engineReady) {
                            KrnlColors.Emerald.copy(alpha = 0.22f)
                        } else {
                            KrnlColors.Crimson
                        },
                        contentColor = if (engineReady) KrnlColors.Emerald else Color.White,
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(
                        text = when {
                            isRunningCheck -> "INITIALIZING OVERLAY..."
                            engineReady -> "RE-RUN OVERLAY DIAGNOSTIC"
                            else -> "RUN OVERLAY DIAGNOSTIC"
                        },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}

@Composable
private fun MenuTabButton(
    title: String,
    icon: ImageVector,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .height(42.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) accent.copy(alpha = 0.16f) else Color.Transparent)
            .border(
                1.dp,
                if (selected) accent.copy(alpha = 0.5f) else Color.Transparent,
                RoundedCornerShape(10.dp),
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (selected) accent else KrnlColors.TextSecondary,
            modifier = Modifier.size(15.dp),
        )
        Spacer(modifier = Modifier.size(5.dp))
        Text(
            text = title,
            color = if (selected) accent else KrnlColors.TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun CyberToggleRow(
    label: String,
    description: String,
    checked: Boolean,
    accent: Color,
    onToggle: (Boolean) -> Unit,
) {
    val trackColor by animateColorAsState(
        targetValue = if (checked) accent else Color(0xFF1E293B),
        label = "toggleTrack",
    )
    val knobOffset by animateDpAsState(
        targetValue = if (checked) 20.dp else 0.dp,
        label = "toggleKnob",
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(KrnlColors.CardSurface)
            .border(1.dp, KrnlColors.CardBorder, RoundedCornerShape(12.dp))
            .clickable { onToggle(!checked) }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
            Text(
                text = label,
                color = KrnlColors.TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = description,
                color = KrnlColors.TextSecondary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        Box(
            modifier = Modifier
                .size(width = 44.dp, height = 24.dp)
                .clip(CircleShape)
                .background(trackColor)
                .padding(3.dp),
        ) {
            Box(
                modifier = Modifier
                    .offset(x = knobOffset)
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(Color.White),
            )
        }
    }
}

@Composable
private fun CyberSliderCard(
    label: String,
    valueText: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    accent: Color,
    onValueChange: (Float) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(KrnlColors.CardSurface)
            .border(1.dp, KrnlColors.CardBorder, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = label,
                color = KrnlColors.TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
            )
            Text(
                text = valueText,
                color = accent,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            colors = SliderDefaults.colors(
                thumbColor = accent,
                activeTrackColor = accent,
                inactiveTrackColor = Color(0x33FFFFFF),
            ),
        )
    }
}
