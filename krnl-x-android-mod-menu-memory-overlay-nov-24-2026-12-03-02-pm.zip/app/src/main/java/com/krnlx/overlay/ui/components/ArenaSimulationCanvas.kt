package com.krnlx.overlay.ui.components

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import com.krnlx.overlay.model.AimBone
import com.krnlx.overlay.model.CrosshairStyle
import com.krnlx.overlay.model.OverlayConfig
import com.krnlx.overlay.model.SimEnemy
import com.krnlx.overlay.ui.theme.KrnlColors
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

private data class LockedTarget(
    val x: Float,
    val y: Float,
    val dist: Float,
    val name: String,
)

@Composable
fun ArenaSimulationCanvas(
    config: OverlayConfig,
    engineReady: Boolean,
    modifier: Modifier = Modifier,
) {
    var timeSec by remember { mutableFloatStateOf(0f) }
    var panX by remember { mutableFloatStateOf(0f) }
    var panY by remember { mutableFloatStateOf(0f) }
    var lockX by remember { mutableFloatStateOf(-1f) }
    var lockY by remember { mutableFloatStateOf(-1f) }
    val aimSimEnabled by rememberUpdatedState(config.aimSimulationEnabled)

    val enemies = remember {
        mutableStateListOf(
            SimEnemy(1, "Ghost_01", -0.45f, 0.48f, 0.52f, 0.4f, 92),
            SimEnemy(2, "Viper_X", 0.14f, 0.62f, 0.44f, 2.1f, 74),
            SimEnemy(3, "Spectre_9", 0.66f, 0.78f, 0.36f, 4.0f, 58),
            SimEnemy(4, "Kestrel_7", -0.76f, 0.85f, 0.61f, 5.2f, 100),
        )
    }

    val labelPaint = remember {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.MONOSPACE
            textSize = 28f
            textAlign = Paint.Align.CENTER
        }
    }
    val labelBgPaint = remember {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.argb(210, 7, 9, 13)
        }
    }
    val hintPaint = remember {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.MONOSPACE
            textSize = 26f
            textAlign = Paint.Align.LEFT
            color = android.graphics.Color.argb(120, 148, 163, 184)
        }
    }

    LaunchedEffect(Unit) {
        val startNanos = System.nanoTime()
        while (true) {
            withFrameNanos { frameNanos ->
                timeSec = (frameNanos - startNanos) / 1_000_000_000f

                for (i in enemies.indices) {
                    val e = enemies[i]
                    if (aimSimEnabled && Random.nextFloat() < 0.015f) {
                        val nextHp = if (e.hp <= 15) 100 else max(12, e.hp - Random.nextInt(4, 14))
                        enemies[i] = e.copy(hp = nextHp)
                    } else if (e.hp < 100 && Random.nextFloat() < 0.01f) {
                        enemies[i] = e.copy(hp = min(100, e.hp + 4))
                    }
                }
            }
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    panX = (panX + dragAmount.x).coerceIn(-360f, 360f)
                    panY = (panY + dragAmount.y).coerceIn(-180f, 180f)
                }
            }
    ) {
        val w = size.width
        val h = size.height
        val cx = w * 0.5f
        val cy = h * 0.5f
        if (lockX < 0f) {
            lockX = cx
            lockY = cy
        }

        // Background Gradient
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF05070B),
                    Color(0xFF0B1019),
                    Color(0xFF101520),
                    Color(0xFF06080D),
                ),
            ),
            size = size,
        )

        val horizonY = h * 0.48f + panY * 0.35f
        val vanishX = w * 0.5f + panX * 0.5f

        // Atmospheric horizon glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0x1800F0FF),
                    Color(0x09FF1E42),
                    Color.Transparent,
                ),
                center = Offset(vanishX, horizonY),
                radius = max(w, h) * 0.55f,
            ),
            radius = max(w, h) * 0.55f,
            center = Offset(vanishX, horizonY),
        )

        // Perspective Ground Grid
        val numRays = 14
        for (i in -numRays..numRays) {
            val bottomX = vanishX + i * (w * 0.14f)
            drawLine(
                color = Color(0x1800F0FF),
                start = Offset(vanishX, horizonY),
                end = Offset(bottomX, h),
                strokeWidth = 1.5f,
            )
        }

        val numRows = 11
        val scroll = (timeSec * 0.25f) % 1f
        for (r in 0 until numRows) {
            val p = (r + scroll) / numRows
            val y = horizonY + p.pow(2.2f) * (h - horizonY)
            drawLine(
                color = Color(0xFF00F0FF).copy(alpha = 0.04f + p * 0.12f),
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 1.5f,
            )
        }

        drawLine(
            color = Color(0x3800F0FF),
            start = Offset(0f, horizonY),
            end = Offset(w, horizonY),
            strokeWidth = 2f,
        )

        // Cover pillars
        val pillars = listOf(
            Triple(-0.34f, 0.09f, 0.16f),
            Triple(-0.14f, 0.06f, 0.11f),
            Triple(0.19f, 0.08f, 0.14f),
            Triple(0.38f, 0.10f, 0.18f),
        )
        for ((rx, rw, rh) in pillars) {
            val sx = vanishX + rx * w
            val sw = rw * w
            val sh = rh * h
            val sy = horizonY - sh * 0.55f
            drawRect(
                color = Color(0xFF0C111A),
                topLeft = Offset(sx - sw / 2f, sy),
                size = Size(sw, sh),
            )
            drawRect(
                color = Color(0x2494A3B8),
                topLeft = Offset(sx - sw / 2f, sy),
                size = Size(sw, sh),
                style = Stroke(width = 1.5f),
            )
        }

        // Enemies & ESP Overlay
        var bestTarget: LockedTarget? = null
        val sorted = enemies.sortedByDescending { it.depth }

        for (enemy in sorted) {
            val strafe = sin(timeSec * enemy.speed + enemy.phase) * 0.24f
            val depthOsc = cos(timeSec * enemy.speed * 0.6f + enemy.phase) * 0.06f
            val depth = (enemy.depth + depthOsc).coerceIn(0.32f, 0.95f)

            val worldX = enemy.baseX + strafe
            val scale = 1.25f - depth * 0.85f
            val screenX = vanishX + worldX * (w * 0.55f) * (1.1f - depth * 0.35f)
            val footY = horizonY + (1f - depth * 0.72f) * (h * 0.34f)
            val boxH = max(110f, 340f * scale)
            val boxW = boxH * 0.48f
            val topY = footY - boxH
            val left = screenX - boxW / 2f
            val distMeters = (depth * 78f + 8f).toInt()

            val headY = topY + boxH * 0.14f
            val neckY = topY + boxH * 0.24f
            val chestY = topY + boxH * 0.38f
            val pelvisY = topY + boxH * 0.56f

            // Tactical Figure
            val headR = max(10f, boxW * 0.16f)
            drawCircle(
                color = Color(0x38CBD5E1),
                radius = headR,
                center = Offset(screenX, headY),
            )
            drawCircle(
                color = Color(0x6BCBD5E1),
                radius = headR,
                center = Offset(screenX, headY),
                style = Stroke(width = 2f),
            )
            drawRoundRect(
                color = Color(0x38CBD5E1),
                topLeft = Offset(screenX - boxW * 0.24f, neckY),
                size = Size(boxW * 0.48f, boxH * 0.34f),
                cornerRadius = CornerRadius(8f, 8f),
            )
            val stride = sin(timeSec * enemy.speed * 4f + enemy.phase) * (boxW * 0.14f)
            val legStroke = max(4f, boxW * 0.11f)
            drawLine(
                color = Color(0x5CCBD5E1),
                start = Offset(screenX - boxW * 0.12f, pelvisY),
                end = Offset(screenX - boxW * 0.16f + stride, footY),
                strokeWidth = legStroke,
            )
            drawLine(
                color = Color(0x5CCBD5E1),
                start = Offset(screenX + boxW * 0.12f, pelvisY),
                end = Offset(screenX + boxW * 0.16f - stride, footY),
                strokeWidth = legStroke,
            )

            // Aimbot FOV Check
            val aimY = when (config.aimBone) {
                AimBone.HEAD -> headY
                AimBone.NECK -> neckY
                AimBone.CHEST -> chestY
            }
            val distCenter = hypot(screenX - cx, aimY - cy)
            if (config.aimSimulationEnabled && distCenter <= config.aimFovRadiusPx) {
                if (bestTarget == null || distCenter < bestTarget.dist) {
                    bestTarget = LockedTarget(screenX, aimY, distCenter, enemy.name)
                }
            }

            // ESP Overlay
            if (config.espEnabled) {
                val isLocked = bestTarget?.name == enemy.name && config.aimSimulationEnabled
                val espColor = if (isLocked) KrnlColors.Cyan else KrnlColors.Crimson

                if (config.espSnaplines) {
                    drawLine(
                        color = espColor.copy(alpha = if (isLocked) 0.78f else 0.45f),
                        start = Offset(cx, 110f),
                        end = Offset(screenX, topY),
                        strokeWidth = if (isLocked) 3f else 2f,
                    )
                }

                if (config.espBoxes) {
                    val corner = max(14f, boxW * 0.28f)
                    val path = Path().apply {
                        moveTo(left, topY + corner)
                        lineTo(left, topY)
                        lineTo(left + corner, topY)

                        moveTo(left + boxW - corner, topY)
                        lineTo(left + boxW, topY)
                        lineTo(left + boxW, topY + corner)

                        moveTo(left + boxW, footY - corner)
                        lineTo(left + boxW, footY)
                        lineTo(left + boxW - corner, footY)

                        moveTo(left + corner, footY)
                        lineTo(left, footY)
                        lineTo(left, footY - corner)
                    }
                    drawPath(
                        path = path,
                        color = espColor,
                        style = Stroke(width = if (isLocked) 4f else 3f),
                    )
                }

                if (config.espSkeleton) {
                    drawLine(
                        color = KrnlColors.Cyan.copy(alpha = 0.8f),
                        start = Offset(screenX, headY),
                        end = Offset(screenX, pelvisY),
                        strokeWidth = 2.5f,
                    )
                    drawLine(
                        color = KrnlColors.Cyan.copy(alpha = 0.8f),
                        start = Offset(screenX - boxW * 0.26f, neckY + 6f),
                        end = Offset(screenX + boxW * 0.26f, neckY + 6f),
                        strokeWidth = 2.5f,
                    )
                    drawCircle(
                        color = KrnlColors.Cyan,
                        radius = 5f,
                        center = Offset(screenX, headY),
                    )
                }

                if (config.espHealthBar) {
                    val hpRatio = enemy.hp / enemy.maxHp.toFloat()
                    val barW = 8f
                    val barX = left - 16f
                    drawRect(
                        color = Color(0xD8080A0E),
                        topLeft = Offset(barX - 2f, topY - 2f),
                        size = Size(barW + 4f, boxH + 4f),
                    )
                    val hpColor = when {
                        hpRatio > 0.6f -> KrnlColors.Emerald
                        hpRatio > 0.3f -> KrnlColors.Amber
                        else -> KrnlColors.Crimson
                    }
                    val fillH = boxH * hpRatio
                    drawRect(
                        color = hpColor,
                        topLeft = Offset(barX, footY - fillH),
                        size = Size(barW, fillH),
                    )

                    val tag = "${enemy.name} · ${distMeters}m"
                    val tw = labelPaint.measureText(tag)
                    drawContext.canvas.nativeCanvas.apply {
                        drawRoundRect(
                            screenX - tw / 2f - 12f,
                            topY - 42f,
                            screenX + tw / 2f + 12f,
                            topY - 8f,
                            8f,
                            8f,
                            labelBgPaint,
                        )
                        labelPaint.color = if (isLocked) {
                            KrnlColors.Cyan.toArgb()
                        } else {
                            KrnlColors.TextPrimary.toArgb()
                        }
                        drawText(tag, screenX, topY - 16f, labelPaint)
                    }
                }
            }
        }

        // FOV Circle & Smooth Tracking Simulation
        if (config.aimSimulationEnabled) {
            val hasTarget = bestTarget != null
            val ringColor = if (hasTarget) KrnlColors.Crimson else KrnlColors.Cyan.copy(alpha = 0.65f)
            drawCircle(
                color = ringColor,
                radius = config.aimFovRadiusPx,
                center = Offset(cx, cy),
                style = Stroke(width = if (hasTarget) 3.2f else 2.4f),
            )

            for (a in 0 until 4) {
                val ang = a * (Math.PI / 2.0)
                val cosA = cos(ang).toFloat()
                val sinA = sin(ang).toFloat()
                drawLine(
                    color = ringColor,
                    start = Offset(
                        cx + cosA * (config.aimFovRadiusPx - 10f),
                        cy + sinA * (config.aimFovRadiusPx - 10f),
                    ),
                    end = Offset(
                        cx + cosA * (config.aimFovRadiusPx + 10f),
                        cy + sinA * (config.aimFovRadiusPx + 10f),
                    ),
                    strokeWidth = 2.5f,
                )
            }

            val tx = bestTarget?.x ?: cx
            val ty = bestTarget?.y ?: cy
            val lerpFactor = ((22f - config.aimSmoothness) * 0.015f).coerceIn(0.03f, 0.35f)
            lockX += (tx - lockX) * lerpFactor
            lockY += (ty - lockY) * lerpFactor

            if (bestTarget != null) {
                drawLine(
                    color = KrnlColors.Cyan.copy(alpha = 0.7f),
                    start = Offset(cx, cy),
                    end = Offset(lockX, lockY),
                    strokeWidth = 2.5f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f),
                )

                val diamond = Path().apply {
                    moveTo(lockX, lockY - 16f)
                    lineTo(lockX + 16f, lockY)
                    lineTo(lockX, lockY + 16f)
                    lineTo(lockX - 16f, lockY)
                    close()
                }
                drawPath(diamond, color = KrnlColors.Crimson, style = Stroke(width = 3f))
            }
        }

        // Custom Pro Crosshair
        if (config.crosshairEnabled) {
            val retColor = Color(config.crosshairColor.hex)
            when (config.crosshairStyle) {
                CrosshairStyle.PRO_T -> {
                    val gap = 10f
                    val len = 20f
                    drawLine(retColor, Offset(cx - gap - len, cy), Offset(cx - gap, cy), strokeWidth = 3.5f)
                    drawLine(retColor, Offset(cx + gap, cy), Offset(cx + gap + len, cy), strokeWidth = 3.5f)
                    drawLine(retColor, Offset(cx, cy + gap), Offset(cx, cy + gap + len), strokeWidth = 3.5f)
                    drawCircle(retColor, radius = 3.5f, center = Offset(cx, cy))
                }
                CrosshairStyle.CYBER_DOT -> {
                    drawCircle(retColor, radius = 4.5f, center = Offset(cx, cy))
                    drawCircle(retColor, radius = 18f, center = Offset(cx, cy), style = Stroke(width = 2.5f))
                }
                CrosshairStyle.DYNAMIC_X -> {
                    val g = 10f
                    val l = 18f
                    drawLine(retColor, Offset(cx - g - l, cy - g - l), Offset(cx - g, cy - g), strokeWidth = 3.2f)
                    drawLine(retColor, Offset(cx + g + l, cy - g - l), Offset(cx + g, cy - g), strokeWidth = 3.2f)
                    drawLine(retColor, Offset(cx - g - l, cy + g + l), Offset(cx - g, cy + g), strokeWidth = 3.2f)
                    drawLine(retColor, Offset(cx + g + l, cy + g + l), Offset(cx + g, cy + g), strokeWidth = 3.2f)
                    drawCircle(retColor, radius = 3f, center = Offset(cx, cy))
                }
            }
        }

        // Bottom-left sandbox hint
        val statusText = if (engineReady) "OVERLAY ACTIVE (SANDBOX)" else "ARENA SIM · DRAG TO AIM PAN"
        drawContext.canvas.nativeCanvas.drawText(statusText, 32f, h - 36f, hintPaint)
    }
}
