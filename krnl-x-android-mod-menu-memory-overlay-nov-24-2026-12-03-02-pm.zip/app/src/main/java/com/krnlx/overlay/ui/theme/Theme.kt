package com.krnlx.overlay.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object KrnlColors {
    val VoidBg = Color(0xFF07090D)
    val GlassSurface = Color(0xE60A0C10)
    val CardSurface = Color(0x0DFFFFFF)
    val CardBorder = Color(0x1EFFFFFF)
    val Crimson = Color(0xFFFF1E42)
    val CrimsonSoft = Color(0xFFFF6B81)
    val Cyan = Color(0xFF00F0FF)
    val Emerald = Color(0xFF10B981)
    val Amber = Color(0xFFF59E0B)
    val TextPrimary = Color(0xFFF8FAFC)
    val TextSecondary = Color(0xFF94A3B8)
    val TextMuted = Color(0xFF64748B)
}

private val KrnlDarkScheme = darkColorScheme(
    primary = KrnlColors.Crimson,
    secondary = KrnlColors.Cyan,
    tertiary = KrnlColors.Emerald,
    background = KrnlColors.VoidBg,
    surface = Color(0xFF0B0E14),
    onPrimary = Color.White,
    onSecondary = Color(0xFF05070B),
    onBackground = KrnlColors.TextPrimary,
    onSurface = KrnlColors.TextPrimary,
)

private val KrnlTypography = Typography(
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 21.sp,
        letterSpacing = (-0.3).sp,
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        fontFeatureSettings = "tnum",
    ),
)

@Composable
fun KrnlXOverlayTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = KrnlDarkScheme,
        typography = KrnlTypography,
        content = content,
    )
}
