export type AimBone = 'head' | 'neck' | 'chest';
export type CrosshairStyle = 'pro-t' | 'cyber-dot' | 'dynamic-x';
export type CrosshairColor = 'cyan' | 'crimson' | 'emerald';
export type MenuTab = 'esp' | 'aim' | 'system';

export interface ModConfig {
  espEnabled: boolean;
  espBoxes: boolean;
  espSnaplines: boolean;
  espHealthBar: boolean;
  espSkeleton: boolean;
  aimbotEnabled: boolean;
  aimbotFov: number;
  aimbotSmoothness: number;
  aimbotBone: AimBone;
  crosshairEnabled: boolean;
  crosshairStyle: CrosshairStyle;
  crosshairColor: CrosshairColor;
  fpsBoosterEnabled: boolean;
  antiLagEnabled: boolean;
  stealthAntiScreenshot: boolean;
}

export interface TerminalLogLine {
  id: string;
  time: string;
  level: 'cmd' | 'info' | 'mem' | 'warn' | 'success';
  text: string;
}

export const DEFAULT_MOD_CONFIG: ModConfig = {
  espEnabled: true,
  espBoxes: true,
  espSnaplines: true,
  espHealthBar: true,
  espSkeleton: true,
  aimbotEnabled: true,
  aimbotFov: 110,
  aimbotSmoothness: 6.5,
  aimbotBone: 'head',
  crosshairEnabled: true,
  crosshairStyle: 'pro-t',
  crosshairColor: 'cyan',
  fpsBoosterEnabled: true,
  antiLagEnabled: true,
  stealthAntiScreenshot: false,
};
