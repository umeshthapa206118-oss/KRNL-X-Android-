export function buildStandaloneSingleFileHtml(): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<title>KRNL-X Android Mod Menu &amp; Game Utility Overlay</title>
<style>
  :root {
    --bg-void: #07090d;
    --glass-bg: rgba(10, 12, 16, 0.9);
    --crimson: #ff1e42;
    --cyan: #00f0ff;
    --emerald: #10b981;
    --border: rgba(255, 255, 255, 0.12);
    --text-main: #f1f5f9;
    --text-muted: #94a3b8;
  }
  * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
  html, body {
    margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden;
    background: var(--bg-void); color: var(--text-main);
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    overscroll-behavior: none; user-select: none;
  }
  .mono {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-variant-numeric: tabular-nums;
  }
  #gameCanvas {
    position: fixed; inset: 0; width: 100%; height: 100%;
    touch-action: none; cursor: crosshair; display: block;
  }
  /* Top FPS HUD */
  .fps-hud {
    position: fixed; top: 12px; left: 12px; z-index: 30;
    display: flex; align-items: center; gap: 10px;
    padding: 8px 14px; border-radius: 12px;
    background: rgba(10, 12, 16, 0.85);
    border: 1px solid rgba(0, 240, 255, 0.35);
    backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px);
    box-shadow: 0 0 20px rgba(0, 240, 255, 0.12);
    font-size: 13px;
  }
  .fps-val { color: var(--cyan); font-weight: 700; }
  .ping-val { color: var(--emerald); font-weight: 600; }
  /* Login Screen */
  .login-backdrop {
    position: fixed; inset: 0; z-index: 60;
    display: flex; align-items: center; justify-content: center; padding: 16px;
    background: rgba(5, 7, 11, 0.88);
    backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);
  }
  .login-card {
    width: 100%; max-width: 420px; border-radius: 18px;
    background: rgba(11, 14, 20, 0.96);
    border: 1px solid var(--border);
    box-shadow: 0 24px 80px rgba(0,0,0,0.85), 0 0 36px rgba(255,30,66,0.16);
    padding: 24px;
  }
  .login-title { margin: 0; font-size: 22px; font-weight: 700; color: #fff; }
  .login-sub { margin: 6px 0 20px; font-size: 12px; color: var(--text-muted); }
  .key-row { display: flex; gap: 8px; flex-wrap: wrap; }
  .key-input {
    flex: 1; min-width: 180px; min-height: 46px; padding: 0 14px;
    border-radius: 12px; background: #07090d; border: 1px solid var(--border);
    color: #fff; font-size: 14px; outline: none;
  }
  .key-input:focus { border-color: var(--cyan); }
  .btn-get-key {
    min-height: 46px; padding: 0 16px; border-radius: 12px;
    background: rgba(0, 240, 255, 0.14); border: 1px solid rgba(0, 240, 255, 0.45);
    color: var(--cyan); font-weight: 700; font-size: 12px; cursor: pointer;
  }
  .btn-unlock {
    width: 100%; min-height: 48px; margin-top: 14px; border-radius: 12px; border: none;
    background: var(--crimson); color: #fff; font-weight: 700; font-size: 14px;
    box-shadow: 0 0 24px rgba(255, 30, 66, 0.42); cursor: pointer;
  }
  .login-err {
    margin-top: 10px; padding: 10px 12px; border-radius: 10px;
    background: rgba(255, 30, 66, 0.14); border: 1px solid rgba(255, 30, 66, 0.35);
    color: #ff6b81; font-size: 12px; display: none;
  }
  /* Floating Bubble */
  .float-bubble {
    position: fixed; top: 0; left: 0; z-index: 50;
    width: 56px; height: 56px; border-radius: 16px;
    background: rgba(10, 12, 16, 0.92);
    border: 1.5px solid var(--cyan);
    box-shadow: 0 0 22px rgba(0, 240, 255, 0.45);
    backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px);
    color: #fff; font-weight: 800; font-size: 13px; letter-spacing: 0.06em;
    display: none; align-items: center; justify-content: center; flex-direction: column;
    touch-action: none; cursor: grab;
  }
  .float-bubble.active { border-color: var(--crimson); box-shadow: 0 0 24px rgba(255, 30, 66, 0.55); }
  /* Mod Menu Panel */
  .menu-wrap {
    position: fixed; inset: 0; z-index: 40;
    display: none; align-items: center; justify-content: center; padding: 12px;
    pointer-events: none;
  }
  .menu-panel {
    pointer-events: auto; width: 100%; max-width: 420px; max-height: 86vh;
    display: flex; flex-direction: column; border-radius: 18px; overflow: hidden;
    background: var(--glass-bg); border: 1px solid var(--border);
    backdrop-filter: blur(18px); -webkit-backdrop-filter: blur(18px);
    box-shadow: 0 24px 80px rgba(0,0,0,0.85), 0 0 32px rgba(0,240,255,0.14);
  }
  .menu-top-bar { height: 2px; background: linear-gradient(90deg, var(--crimson), var(--cyan), var(--crimson)); }
  .menu-header {
    padding: 12px 14px; background: rgba(255,255,255,0.03);
    border-bottom: 1px solid var(--border);
    display: flex; align-items: center; justify-content: space-between; gap: 10px;
    touch-action: none; cursor: grab;
  }
  .menu-title { font-size: 14px; font-weight: 700; letter-spacing: 0.04em; }
  .menu-sub { font-size: 11px; color: var(--text-muted); margin-top: 2px; }
  .btn-min {
    min-width: 38px; min-height: 38px; border-radius: 10px;
    background: rgba(255, 30, 66, 0.16); border: 1px solid rgba(255, 30, 66, 0.45);
    color: #ff6b81; font-weight: 700; font-size: 14px; cursor: pointer;
  }
  .tabs {
    display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px;
    padding: 8px; background: rgba(7,9,13,0.72); border-bottom: 1px solid var(--border);
  }
  .tab-btn {
    min-height: 40px; border-radius: 10px; border: 1px solid transparent;
    background: transparent; color: var(--text-muted); font-size: 12px; font-weight: 600;
    cursor: pointer;
  }
  .tab-btn.active {
    background: rgba(0, 240, 255, 0.15); color: var(--cyan);
    border-color: rgba(0, 240, 255, 0.45);
  }
  .menu-body { flex: 1; overflow-y: auto; padding: 12px; display: flex; flex-direction: column; gap: 8px; }
  .tab-pane { display: none; flex-direction: column; gap: 8px; }
  .tab-pane.active { display: flex; }
  .row-card {
    min-height: 48px; padding: 10px 12px; border-radius: 12px;
    background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08);
    display: flex; align-items: center; justify-content: space-between; gap: 12px;
    cursor: pointer;
  }
  .row-label { font-size: 13px; font-weight: 600; color: #f8fafc; }
  .row-desc { font-size: 11px; color: var(--text-muted); margin-top: 2px; }
  .switch {
    width: 44px; height: 24px; border-radius: 999px; padding: 2px;
    background: #1e293b; border: 1px solid rgba(255,255,255,0.1);
    display: flex; align-items: center; transition: 0.2s; flex-shrink: 0;
  }
  .switch.on { background: var(--cyan); box-shadow: 0 0 12px rgba(0,240,255,0.55); }
  .switch.on.crimson { background: var(--crimson); box-shadow: 0 0 12px rgba(255,30,66,0.6); }
  .switch-knob {
    width: 18px; height: 18px; border-radius: 50%; background: #fff;
    transition: transform 0.2s;
  }
  .switch.on .switch-knob { transform: translateX(20px); }
  .slider-card {
    padding: 10px 12px; border-radius: 12px;
    background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08);
  }
  .slider-head { display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 6px; }
  input[type=range] { width: 100%; accent-color: var(--cyan); height: 26px; cursor: pointer; }
  /* Terminal */
  .term-box {
    border-top: 1px solid var(--border); background: rgba(6, 8, 12, 0.96);
    padding: 10px 12px; display: flex; flex-direction: column; gap: 8px;
  }
  .term-log {
    height: 115px; overflow-y: auto; border-radius: 10px;
    background: #040508; border: 1px solid rgba(255,255,255,0.1);
    padding: 8px 10px; font-size: 11px; line-height: 1.5; user-select: text;
  }
  .btn-inject {
    width: 100%; min-height: 44px; border-radius: 12px; border: none;
    background: linear-gradient(90deg, #ff1e42, #d91436); color: #fff;
    font-size: 12px; font-weight: 700; letter-spacing: 0.06em; cursor: pointer;
    box-shadow: 0 0 22px rgba(255, 30, 66, 0.4);
  }
</style>
</head>
<body>
<canvas id="gameCanvas"></canvas>

<div class="fps-hud mono" id="fpsHud">
  <span class="fps-val" id="fpsVal">120 FPS</span>
  <span style="color:#475569">·</span>
  <span class="ping-val" id="pingVal">14 ms</span>
  <span style="color:#475569">·</span>
  <span id="hookBadge" style="color:#94a3b8;font-size:11px">STANDBY</span>
</div>

<!-- VIP Key Login Gate -->
<div class="login-backdrop" id="loginGate">
  <div class="login-card">
    <h1 class="login-title">KRNL-X VIP Overlay</h1>
    <p class="login-sub mono">Android ARM64-v8a · ImGui Memory Utility</p>
    <div class="key-row">
      <input id="keyInput" class="key-input mono" type="text" placeholder="KRNL-VIP-XXXX-ARM64" autocomplete="off" />
      <button id="btnGetKey" class="btn-get-key" type="button">GET KEY</button>
    </div>
    <div id="loginErr" class="login-err">Invalid key. Tap GET KEY to auto-fill a valid VIP key.</div>
    <button id="btnUnlock" class="btn-unlock" type="button">VERIFY &amp; UNLOCK MENU</button>
  </div>
</div>

<!-- Draggable Floating Bubble -->
<button id="floatBubble" class="float-bubble mono" type="button" aria-label="Toggle Mod Menu">KX</button>

<!-- Floating ImGui Mod Menu -->
<div class="menu-wrap" id="menuWrap">
  <section class="menu-panel" id="menuPanel">
    <div class="menu-top-bar"></div>
    <div class="menu-header" id="menuHeader">
      <div>
        <div class="menu-title">KRNL-X MOD MENU</div>
        <div class="menu-sub mono" id="licenseSub">VIP · ARM64-v8a</div>
      </div>
      <button class="btn-min" id="btnMin" type="button" title="Collapse">_</button>
    </div>

    <div class="tabs">
      <button class="tab-btn active" data-tab="esp" type="button">ESP Visuals</button>
      <button class="tab-btn" data-tab="aim" type="button">Aim &amp; FOV</button>
      <button class="tab-btn" data-tab="sys" type="button">120 FPS</button>
    </div>

    <div class="menu-body">
      <div class="tab-pane active" id="pane-esp">
        <div class="row-card" data-toggle="esp">
          <div><div class="row-label">ESP Box &amp; Player Info</div><div class="row-desc">Live enemy hitboxes, HP bars &amp; distance</div></div>
          <div class="switch on crimson" id="sw-esp"><div class="switch-knob"></div></div>
        </div>
        <div class="row-card" data-toggle="snap">
          <div><div class="row-label">ESP Snaplines &amp; Head Dot</div><div class="row-desc">Draw tracers &amp; skeletal head marker</div></div>
          <div class="switch on" id="sw-snap"><div class="switch-knob"></div></div>
        </div>
      </div>

      <div class="tab-pane" id="pane-aim">
        <div class="row-card" data-toggle="aim">
          <div><div class="row-label">Aimbot &amp; FOV Lock</div><div class="row-desc">Center FOV circle &amp; smooth target tracking</div></div>
          <div class="switch on crimson" id="sw-aim"><div class="switch-knob"></div></div>
        </div>
        <div class="slider-card">
          <div class="slider-head"><span>FOV Circle Size</span><span class="mono" style="color:var(--cyan)" id="fovReadout">110 px</span></div>
          <input type="range" id="fovSlider" min="40" max="220" step="2" value="110" />
        </div>
        <div class="slider-card">
          <div class="slider-head"><span>Aimbot Smoothness</span><span class="mono" style="color:#ff6b81" id="smoothReadout">6.5x</span></div>
          <input type="range" id="smoothSlider" min="1" max="20" step="0.5" value="6.5" />
        </div>
        <div class="row-card" data-toggle="crosshair">
          <div><div class="row-label">Custom Pro Crosshair</div><div class="row-desc">Sharp center-screen tactical reticle</div></div>
          <div class="switch on" id="sw-crosshair"><div class="switch-knob"></div></div>
        </div>
      </div>

      <div class="tab-pane" id="pane-sys">
        <div class="row-card" data-toggle="fps">
          <div><div class="row-label">120 FPS &amp; Anti-Lag Booster</div><div class="row-desc">Unlock 120Hz frame pacing &amp; optimize ping</div></div>
          <div class="switch on" id="sw-fps"><div class="switch-knob"></div></div>
        </div>
      </div>
    </div>

    <div class="term-box">
      <div class="mono" style="font-size:11px;color:#94a3b8;">python3 · pymem / frida console</div>
      <div class="term-log mono" id="termLog">
        <div style="color:#64748b">Ready. Tap INJECT PYTHON BYPASS to attach frida-gadget.</div>
      </div>
      <button class="btn-inject" id="btnInject" type="button">INJECT PYTHON BYPASS</button>
    </div>
  </section>
</div>

<script>
(function(){
  const state = {
    esp: true, snap: true, aim: true, crosshair: true, fpsBooster: true,
    fov: 110, smoothness: 6.5, bypassed: false, menuOpen: true, panX: 0, panY: 0
  };

  // Login Logic
  const loginGate = document.getElementById('loginGate');
  const keyInput = document.getElementById('keyInput');
  const loginErr = document.getElementById('loginErr');
  const floatBubble = document.getElementById('floatBubble');
  const menuWrap = document.getElementById('menuWrap');

  document.getElementById('btnGetKey').onclick = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let tok = '';
    for (let i = 0; i < 4; i++) tok += chars[Math.floor(Math.random() * chars.length)];
    keyInput.value = 'KRNL-VIP-' + tok + '-ARM64';
    loginErr.style.display = 'none';
  };

  document.getElementById('btnUnlock').onclick = () => {
    const val = keyInput.value.trim().toUpperCase();
    if (!/^KRNL-VIP-[A-Z0-9]{4}-ARM64$/.test(val) && val !== 'DEMO') {
      loginErr.style.display = 'block';
      return;
    }
    document.getElementById('licenseSub').textContent = val + ' · ARM64-v8a';
    loginGate.style.display = 'none';
    floatBubble.style.display = 'flex';
    menuWrap.style.display = 'flex';
  };

  // Draggable Bubble (GPU translate3d, zero lag on mobile WebViews)
  let bx = 18, by = 84, bDrag = false, bMoved = false, bsx = 0, bsy = 0, box = 18, boy = 84;
  floatBubble.style.transform = 'translate3d(' + bx + 'px,' + by + 'px,0)';
  floatBubble.addEventListener('pointerdown', (e) => {
    bDrag = true; bMoved = false; bsx = e.clientX; bsy = e.clientY; box = bx; boy = by;
    floatBubble.setPointerCapture(e.pointerId);
  });
  floatBubble.addEventListener('pointermove', (e) => {
    if (!bDrag) return;
    const dx = e.clientX - bsx, dy = e.clientY - bsy;
    if (Math.hypot(dx, dy) > 6) bMoved = true;
    bx = Math.min(Math.max(10, box + dx), window.innerWidth - 66);
    by = Math.min(Math.max(10, boy + dy), window.innerHeight - 66);
    floatBubble.style.transform = 'translate3d(' + bx + 'px,' + by + 'px,0)';
  });
  floatBubble.addEventListener('pointerup', (e) => {
    if (!bDrag) return;
    bDrag = false;
    if (floatBubble.hasPointerCapture(e.pointerId)) floatBubble.releasePointerCapture(e.pointerId);
    if (!bMoved) {
      state.menuOpen = !state.menuOpen;
      menuWrap.style.display = state.menuOpen ? 'flex' : 'none';
      floatBubble.classList.toggle('active', state.menuOpen);
    }
  });
  document.getElementById('btnMin').onclick = () => {
    state.menuOpen = false;
    menuWrap.style.display = 'none';
    floatBubble.classList.remove('active');
  };

  // Tabs
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.onclick = () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById('pane-' + btn.dataset.tab).classList.add('active');
    };
  });

  // Toggles & Sliders
  const bindToggle = (attr, key, swId) => {
    document.querySelector('[data-toggle="' + attr + '"]').onclick = () => {
      state[key] = !state[key];
      document.getElementById(swId).classList.toggle('on', state[key]);
    };
  };
  bindToggle('esp', 'esp', 'sw-esp');
  bindToggle('snap', 'snap', 'sw-snap');
  bindToggle('aim', 'aim', 'sw-aim');
  bindToggle('crosshair', 'crosshair', 'sw-crosshair');
  bindToggle('fps', 'fpsBooster', 'sw-fps');

  document.getElementById('fovSlider').oninput = (e) => {
    state.fov = Number(e.target.value);
    document.getElementById('fovReadout').textContent = state.fov + ' px';
  };
  document.getElementById('smoothSlider').oninput = (e) => {
    state.smoothness = Number(e.target.value);
    document.getElementById('smoothReadout').textContent = state.smoothness.toFixed(1) + 'x';
  };

  // Live FPS HUD
  setInterval(() => {
    const fps = state.fpsBooster ? 117 + Math.floor(Math.random()*4) : 57 + Math.floor(Math.random()*4);
    const ping = state.fpsBooster ? 12 + Math.floor(Math.random()*5) : 58 + Math.floor(Math.random()*16);
    document.getElementById('fpsVal').textContent = fps + ' FPS';
    document.getElementById('pingVal').textContent = ping + ' ms';
  }, 650);

  // Python Injection Simulation
  const termLog = document.getElementById('termLog');
  const appendLog = (txt, color) => {
    const d = document.createElement('div');
    d.style.color = color || '#cbd5e1';
    d.textContent = txt;
    termLog.appendChild(d);
    termLog.scrollTop = termLog.scrollHeight;
  };
  let injecting = false;
  document.getElementById('btnInject').onclick = () => {
    if (injecting) return;
    injecting = true;
    termLog.innerHTML = '';
    const steps = [
      [0, '$ python3 core_hook.py --arch arm64-v8a --pid 18492', '#00f0ff'],
      [280, '[*] Importing pymem & frida-gadget-16.2.1-arm64.so...', '#cbd5e1'],
      [620, '[*] Attached com.game.tactical.arena (UID 10284)', '#cbd5e1'],
      [960, '[MEM] libil2cpp.so base => 0x7b4a200000', '#fcd34d'],
      [1280, '[MEM] Patching AntiCheat$$CheckIntegrity (+0x289B104) -> NOP', '#fcd34d'],
      [1600, '[*] Hooking anogs.so CRC32 telemetry thread...', '#ff6b81'],
      [1950, 'SUCCESS! Bypass active — ARM64 hooks locked.', '#10b981']
    ];
    steps.forEach(([ms, msg, col], idx) => {
      setTimeout(() => {
        appendLog(msg, col);
        if (idx === steps.length - 1) {
          injecting = false;
          state.bypassed = true;
          document.getElementById('hookBadge').textContent = 'ARM64 HOOKED';
          document.getElementById('hookBadge').style.color = '#10b981';
        }
      }, ms);
    });
  };

  // Live Tactical Game Canvas
  const canvas = document.getElementById('gameCanvas');
  const ctx = canvas.getContext('2d');
  const enemies = [
    { name: 'Ghost_01', bx: -0.45, d: 0.48, spd: 0.52, ph: 0.4, hp: 92 },
    { name: 'Viper_X', bx: 0.14, d: 0.62, spd: 0.44, ph: 2.1, hp: 74 },
    { name: 'Spectre_9', bx: 0.66, d: 0.78, spd: 0.36, ph: 4.0, hp: 58 },
    { name: 'Kestrel_7', bx: -0.74, d: 0.85, spd: 0.6, ph: 5.2, hp: 100 }
  ];
  let cDrag = false, clx = 0, cly = 0;
  canvas.addEventListener('pointerdown', (e) => { cDrag = true; clx = e.clientX; cly = e.clientY; });
  canvas.addEventListener('pointermove', (e) => {
    if (!cDrag) return;
    state.panX = Math.max(-220, Math.min(220, state.panX + e.clientX - clx));
    state.panY = Math.max(-100, Math.min(100, state.panY + e.clientY - cly));
    clx = e.clientX; cly = e.clientY;
  });
  window.addEventListener('pointerup', () => { cDrag = false; });

  const resize = () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  };
  resize();
  window.addEventListener('resize', resize);

  function loop(now) {
    const t = now / 1000, w = canvas.width, h = canvas.height, cx = w/2, cy = h/2;
    ctx.fillStyle = '#07090d'; ctx.fillRect(0, 0, w, h);
    const hy = h * 0.48 + state.panY * 0.35, vx = w * 0.5 + state.panX * 0.5;
    ctx.strokeStyle = 'rgba(0,240,255,0.12)'; ctx.lineWidth = 1;
    for (let i = -12; i <= 12; i++) {
      ctx.beginPath(); ctx.moveTo(vx, hy); ctx.lineTo(vx + i * w * 0.14, h); ctx.stroke();
    }
    ctx.beginPath(); ctx.moveTo(0, hy); ctx.lineTo(w, hy); ctx.stroke();

    let lock = null;
    enemies.forEach((en) => {
      const sx = vx + (en.bx + Math.sin(t * en.spd + en.ph) * 0.24) * w * 0.52;
      const fy = hy + (1 - en.d * 0.72) * h * 0.34;
      const bh = Math.max(54, 170 * (1.25 - en.d * 0.85));
      const bw = bh * 0.48, ty = fy - bh, headY = ty + bh * 0.15;
      ctx.fillStyle = 'rgba(203,213,225,0.22)';
      ctx.beginPath(); ctx.arc(sx, headY, Math.max(5, bw*0.16), 0, Math.PI*2); ctx.fill();
      ctx.fillRect(sx - bw*0.22, ty + bh*0.24, bw*0.44, bh*0.42);

      const distC = Math.hypot(sx - cx, headY - cy);
      if (state.aim && distC <= state.fov && (!lock || distC < lock.d)) lock = { x: sx, y: headY, d: distC };

      if (state.esp) {
        ctx.strokeStyle = '#ff1e42'; ctx.lineWidth = 1.6;
        ctx.strokeRect(sx - bw/2, ty, bw, bh);
        if (state.snap) {
          ctx.strokeStyle = 'rgba(0,240,255,0.5)'; ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(cx, 50); ctx.lineTo(sx, ty); ctx.stroke();
        }
        ctx.fillStyle = '#10b981';
        ctx.fillRect(sx - bw/2 - 6, fy - bh * (en.hp/100), 3, bh * (en.hp/100));
        ctx.font = '600 11px monospace'; ctx.fillStyle = '#f8fafc'; ctx.textAlign = 'center';
        ctx.fillText(en.name + ' · ' + Math.round(en.d*75) + 'm', sx, ty - 7);
      }
    });

    if (state.aim) {
      ctx.beginPath(); ctx.arc(cx, cy, state.fov, 0, Math.PI*2);
      ctx.strokeStyle = lock ? '#ff1e42' : 'rgba(0,240,255,0.65)';
      ctx.lineWidth = 1.6; ctx.stroke();
      if (lock) {
        ctx.strokeStyle = '#00f0ff'; ctx.setLineDash([4,4]);
        ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(lock.x, lock.y); ctx.stroke();
        ctx.setLineDash([]);
      }
    }

    if (state.crosshair) {
      ctx.strokeStyle = '#00f0ff'; ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.moveTo(cx - 14, cy); ctx.lineTo(cx - 5, cy);
      ctx.moveTo(cx + 5, cy); ctx.lineTo(cx + 14, cy);
      ctx.moveTo(cx, cy + 5); ctx.lineTo(cx, cy + 14);
      ctx.stroke();
      ctx.fillStyle = '#00f0ff';
      ctx.beginPath(); ctx.arc(cx, cy, 2, 0, Math.PI*2); ctx.fill();
    }
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
})();
</script>
</body>
</html>`;
}
