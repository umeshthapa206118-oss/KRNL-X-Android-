import { useCallback, useEffect, useRef, useState } from 'react';
import { ExportHtmlModal } from './components/ExportHtmlModal';
import { FloatingBubble } from './components/FloatingBubble';
import { FpsHud } from './components/FpsHud';
import { GameViewportCanvas } from './components/GameViewportCanvas';
import { LoginOverlay } from './components/LoginOverlay';
import { ModMenuPanel } from './components/ModMenuPanel';
import { DEFAULT_MOD_CONFIG, ModConfig, TerminalLogLine } from './types/modMenu';

const STORAGE_KEY = 'krnlx_mod_config_v1';

function formatLogTime(): string {
  const d = new Date();
  return d.toTimeString().slice(0, 8);
}

export default function App() {
  const [unlocked, setUnlocked] = useState(false);
  const [licenseKey, setLicenseKey] = useState('');
  const [menuOpen, setMenuOpen] = useState(true);
  const [exportOpen, setExportOpen] = useState(false);

  const [config, setConfig] = useState<ModConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return { ...DEFAULT_MOD_CONFIG, ...JSON.parse(saved) };
      }
    } catch {
      // Ignore storage errors in restricted WebViews
    }
    return DEFAULT_MOD_CONFIG;
  });

  const [bypassActive, setBypassActive] = useState(false);
  const [isInjecting, setIsInjecting] = useState(false);
  const [logs, setLogs] = useState<TerminalLogLine[]>([]);
  const timersRef = useRef<number[]>([]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
    } catch {
      // Ignore storage errors
    }
  }, [config]);

  useEffect(() => {
    return () => {
      timersRef.current.forEach((t) => window.clearTimeout(t));
    };
  }, []);

  const handleUnlock = useCallback((key: string) => {
    setLicenseKey(key);
    setUnlocked(true);
    setMenuOpen(true);
  }, []);

  const handleResetConfig = useCallback(() => {
    setConfig(DEFAULT_MOD_CONFIG);
  }, []);

  const handleClearLogs = useCallback(() => {
    setLogs([]);
  }, []);

  const handleInjectBypass = useCallback(() => {
    if (isInjecting) return;

    timersRef.current.forEach((t) => window.clearTimeout(t));
    timersRef.current = [];

    setIsInjecting(true);
    setBypassActive(false);
    setLogs([]);

    const steps: { delay: number; level: TerminalLogLine['level']; text: string }[] = [
      {
        delay: 40,
        level: 'cmd',
        text: '$ python3 core_hook.py --arch arm64-v8a --pid 18492',
      },
      {
        delay: 320,
        level: 'info',
        text: '[*] Loading pymem 1.13.1 & frida-gadget-16.2.1-android-arm64.so...',
      },
      {
        delay: 640,
        level: 'info',
        text: '[*] Attaching to com.game.tactical.arena (UID 10284, ABI arm64-v8a)',
      },
      {
        delay: 980,
        level: 'mem',
        text: '[MEM] libil2cpp.so base => 0x7b4a200000 (RWX map verified)',
      },
      {
        delay: 1300,
        level: 'mem',
        text: '[MEM] Resolved PlayerController$$Update => +0x1A4F2C0',
      },
      {
        delay: 1620,
        level: 'warn',
        text: '[*] Patching AntiCheatDetector$$CheckIntegrity (+0x289B104) -> NOP (1F 20 03 D5)',
      },
      {
        delay: 1960,
        level: 'mem',
        text: '[MEM] Neutralized libanogs.so CRC32 heartbeat thread (0x7b3e014880)',
      },
      {
        delay: 2320,
        level: 'success',
        text: 'SUCCESS! Memory hooks & anti-cheat bypass active in 1.42s.',
      },
    ];

    steps.forEach((step, idx) => {
      const timerId = window.setTimeout(() => {
        setLogs((prev) => [
          ...prev,
          {
            id: `${Date.now()}-${idx}`,
            time: formatLogTime(),
            level: step.level,
            text: step.text,
          },
        ]);
        if (idx === steps.length - 1) {
          setIsInjecting(false);
          setBypassActive(true);
        }
      }, step.delay);
      timersRef.current.push(timerId);
    });
  }, [isInjecting]);

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-[#07090d]">
      {/* Live Interactive 2.5D Tactical Game Simulation Viewport */}
      <GameViewportCanvas config={config} bypassActive={bypassActive} />

      {/* Stream-Proof Anti-Screenshot Frame Simulation */}
      {unlocked && config.stealthAntiScreenshot && (
        <div
          aria-hidden="true"
          className="fixed inset-0 z-20 pointer-events-none border-2 border-[#ff1e42]/35 shadow-[inset_0_0_40px_rgba(255,30,66,0.12)]"
        />
      )}

      {/* Top Live FPS / Ping / Memory Hook HUD */}
      <FpsHud
        config={config}
        bypassActive={bypassActive}
        unlocked={unlocked}
        onOpenExport={() => setExportOpen(true)}
      />

      {/* VIP Activation Key Gate OR Unlocked Overlay */}
      {!unlocked ? (
        <LoginOverlay onUnlock={handleUnlock} />
      ) : (
        <>
          <FloatingBubble
            menuOpen={menuOpen}
            bypassActive={bypassActive}
            onToggleMenu={() => setMenuOpen((prev) => !prev)}
          />
          <ModMenuPanel
            isOpen={menuOpen}
            licenseKey={licenseKey}
            config={config}
            bypassActive={bypassActive}
            isInjecting={isInjecting}
            logs={logs}
            onChangeConfig={setConfig}
            onResetConfig={handleResetConfig}
            onMinimize={() => setMenuOpen(false)}
            onInjectBypass={handleInjectBypass}
            onClearLogs={handleClearLogs}
          />
          <ExportHtmlModal open={exportOpen} onClose={() => setExportOpen(false)} />
        </>
      )}
    </main>
  );
}
