import React, { useEffect, useRef, useState } from 'react';
import { Crosshair, Shield } from 'lucide-react';

interface FloatingBubbleProps {
  menuOpen: boolean;
  bypassActive: boolean;
  onToggleMenu: () => void;
}

export const FloatingBubble: React.FC<FloatingBubbleProps> = ({
  menuOpen,
  bypassActive,
  onToggleMenu,
}) => {
  const [pos, setPos] = useState({ x: 18, y: 84 });
  const dragState = useRef<{
    active: boolean;
    pointerId: number | null;
    startX: number;
    startY: number;
    originX: number;
    originY: number;
    moved: boolean;
  }>({
    active: false,
    pointerId: null,
    startX: 0,
    startY: 0,
    originX: 18,
    originY: 84,
    moved: false,
  });

  useEffect(() => {
    const clampToViewport = () => {
      const maxX = Math.max(12, window.innerWidth - 68);
      const maxY = Math.max(12, window.innerHeight - 68);
      setPos((prev) => ({
        x: Math.min(Math.max(12, prev.x), maxX),
        y: Math.min(Math.max(12, prev.y), maxY),
      }));
    };
    window.addEventListener('resize', clampToViewport);
    return () => window.removeEventListener('resize', clampToViewport);
  }, []);

  const handlePointerDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    e.currentTarget.setPointerCapture(e.pointerId);
    dragState.current = {
      active: true,
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      originX: pos.x,
      originY: pos.y,
      moved: false,
    };
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (!dragState.current.active || dragState.current.pointerId !== e.pointerId) return;
    const dx = e.clientX - dragState.current.startX;
    const dy = e.clientY - dragState.current.startY;
    if (Math.hypot(dx, dy) > 6) {
      dragState.current.moved = true;
    }
    const maxX = Math.max(12, window.innerWidth - 68);
    const maxY = Math.max(12, window.innerHeight - 68);
    const nextX = Math.min(Math.max(12, dragState.current.originX + dx), maxX);
    const nextY = Math.min(Math.max(12, dragState.current.originY + dy), maxY);
    setPos({ x: nextX, y: nextY });
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (!dragState.current.active || dragState.current.pointerId !== e.pointerId) return;
    const wasTap = !dragState.current.moved;
    dragState.current.active = false;
    dragState.current.pointerId = null;
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
    if (wasTap) {
      onToggleMenu();
    }
  };

  return (
    <button
      type="button"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      style={{
        transform: `translate3d(${pos.x}px, ${pos.y}px, 0)`,
      }}
      aria-label={menuOpen ? 'Collapse Mod Menu Overlay' : 'Open Mod Menu Overlay'}
      title="Drag to move · Tap to toggle Mod Menu"
      className={`fixed top-0 left-0 z-50 w-14 h-14 rounded-2xl touch-none select-none flex items-center justify-center border backdrop-blur-xl transition-shadow duration-200 cursor-grab active:cursor-grabbing active:scale-95 ${
        menuOpen
          ? 'bg-[#ff1e42]/20 border-[#ff1e42] shadow-[0_0_24px_rgba(255,30,66,0.55)]'
          : bypassActive
          ? 'bg-[#0a0c10]/90 border-[#00f0ff] shadow-[0_0_24px_rgba(0,240,255,0.45)]'
          : 'bg-[#0a0c10]/90 border-white/25 shadow-[0_10px_30px_rgba(0,0,0,0.7)]'
      }`}
    >
      <div className="relative flex items-center justify-center">
        {bypassActive ? (
          <Shield className={`w-6 h-6 ${menuOpen ? 'text-[#ff1e42]' : 'text-[#00f0ff]'}`} />
        ) : (
          <Crosshair className={`w-6 h-6 ${menuOpen ? 'text-[#ff1e42]' : 'text-white'}`} />
        )}
        <span
          className={`absolute -bottom-2.5 text-[9px] font-mono font-bold tracking-wider ${
            menuOpen ? 'text-[#ff1e42]' : 'text-[#00f0ff]'
          }`}
        >
          KX
        </span>
      </div>
    </button>
  );
};
