import React, { useMemo, useState } from 'react';
import { Check, Copy, Download, X } from 'lucide-react';
import { buildStandaloneSingleFileHtml } from '../utils/standaloneHtml';

interface ExportHtmlModalProps {
  open: boolean;
  onClose: () => void;
}

export const ExportHtmlModal: React.FC<ExportHtmlModalProps> = ({ open, onClose }) => {
  const [copied, setCopied] = useState(false);
  const htmlCode = useMemo(() => buildStandaloneSingleFileHtml(), []);

  if (!open) return null;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(htmlCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Fallback textarea copy
      const ta = document.createElement('textarea');
      ta.value = htmlCode;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    }
  };

  const handleDownload = () => {
    const blob = new Blob([htmlCode], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'krnlx_mod_overlay.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="w-full max-w-2xl max-h-[85vh] flex flex-col rounded-2xl bg-[#0a0c10] border border-white/15 shadow-2xl overflow-hidden">
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-white">Standalone Single-File HTML</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Zero external dependencies — ready to open directly on Android WebView or mobile browser.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close export modal"
            className="w-10 h-10 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center text-slate-300 hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 flex-1 overflow-hidden flex flex-col gap-3">
          <pre className="flex-1 overflow-auto cyber-scroll rounded-xl bg-[#05070b] border border-white/10 p-3.5 text-[11px] font-mono text-slate-300 leading-relaxed select-text">
            {htmlCode}
          </pre>
        </div>

        <div className="px-5 py-4 border-t border-white/10 flex flex-wrap items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={handleCopy}
            className="min-h-[44px] px-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/15 text-xs font-semibold text-slate-100 flex items-center gap-2 transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-[#00f0ff]" />}
            <span>{copied ? 'Copied to Clipboard' : 'Copy Single-File Code'}</span>
          </button>
          <button
            type="button"
            onClick={handleDownload}
            className="min-h-[44px] px-4 rounded-xl bg-[#00f0ff] hover:bg-[#33f3ff] text-[#05070b] text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Download .HTML</span>
          </button>
        </div>
      </div>
    </div>
  );
};
