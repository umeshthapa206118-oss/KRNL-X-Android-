import React, { useEffect, useRef } from 'react';
import { ModConfig } from '../types/modMenu';

interface GameViewportCanvasProps {
  config: ModConfig;
  bypassActive: boolean;
}

interface SimEnemy {
  id: number;
  name: string;
  baseX: number; // -1.2 to 1.2 normalized horizontal world pos
  depth: number; // 0.35 (close) to 1.0 (far)
  speed: number;
  phase: number;
  hp: number;
  maxHp: number;
  teamColor: string;
}

const INITIAL_ENEMIES: SimEnemy[] = [
  { id: 1, name: 'Ghost_01', baseX: -0.45, depth: 0.48, speed: 0.52, phase: 0.4, hp: 92, maxHp: 100, teamColor: '#ff1e42' },
  { id: 2, name: 'Viper_X', baseX: 0.12, depth: 0.62, speed: 0.44, phase: 2.1, hp: 74, maxHp: 100, teamColor: '#ff1e42' },
  { id: 3, name: 'Spectre_9', baseX: 0.68, depth: 0.78, speed: 0.36, phase: 4.0, hp: 55, maxHp: 100, teamColor: '#ff1e42' },
  { id: 4, name: 'Kestrel_7', baseX: -0.78, depth: 0.85, speed: 0.61, phase: 5.2, hp: 100, maxHp: 100, teamColor: '#ff1e42' },
];

export const GameViewportCanvas: React.FC<GameViewportCanvasProps> = ({ config, bypassActive }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const configRef = useRef(config);
  const bypassRef = useRef(bypassActive);
  const aimOffsetRef = useRef({ x: 0, y: 0 });
  const dragRef = useRef<{ active: boolean; lastX: number; lastY: number }>({
    active: false,
    lastX: 0,
    lastY: 0,
  });
  const lockCursorRef = useRef({ x: 0, y: 0, initialized: false });

  useEffect(() => {
    configRef.current = config;
  }, [config]);

  useEffect(() => {
    bypassRef.current = bypassActive;
  }, [bypassActive]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId = 0;
    const enemies = INITIAL_ENEMIES.map((e) => ({ ...e }));

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.floor(window.innerWidth * dpr);
      canvas.height = Math.floor(window.innerHeight * dpr);
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    resize();
    window.addEventListener('resize', resize);

    let lastTime = performance.now();

    const drawArenaBackground = (w: number, h: number, t: number, panX: number, panY: number) => {
      // Deep tactical night sky & floor gradient
      const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
      bgGrad.addColorStop(0, '#05070b');
      bgGrad.addColorStop(0.48, '#0b1019');
      bgGrad.addColorStop(0.5, '#101520');
      bgGrad.addColorStop(1, '#06080d');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      const horizonY = h * 0.48 + panY * 0.35;
      const vanishX = w * 0.5 + panX * 0.5;

      // Subtle atmospheric glow on horizon
      const glow = ctx.createRadialGradient(vanishX, horizonY, 10, vanishX, horizonY, Math.max(w, h) * 0.55);
      glow.addColorStop(0, 'rgba(0, 240, 255, 0.08)');
      glow.addColorStop(0.5, 'rgba(255, 30, 66, 0.03)');
      glow.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = glow;
      ctx.fillRect(0, 0, w, h);

      // Perspective ground grid
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, horizonY, w, h - horizonY);
      ctx.clip();

      ctx.strokeStyle = 'rgba(0, 240, 255, 0.09)';
      ctx.lineWidth = 1;

      const numRays = 16;
      for (let i = -numRays; i <= numRays; i++) {
        const bottomX = vanishX + i * (w * 0.14);
        ctx.beginPath();
        ctx.moveTo(vanishX, horizonY);
        ctx.lineTo(bottomX, h);
        ctx.stroke();
      }

      const numRows = 12;
      const scroll = (t * 0.25) % 1;
      for (let r = 0; r < numRows; r++) {
        const p = (r + scroll) / numRows;
        const y = horizonY + Math.pow(p, 2.2) * (h - horizonY);
        ctx.strokeStyle = `rgba(0, 240, 255, ${0.03 + p * 0.1})`;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }
      ctx.restore();

      // Horizon line
      ctx.strokeStyle = 'rgba(0, 240, 255, 0.22)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, horizonY);
      ctx.lineTo(w, horizonY);
      ctx.stroke();

      // Tactical silhouettes / architectural cover pillars
      const structures = [
        { rx: -0.34, rw: 0.09, rh: 0.16 },
        { rx: -0.14, rw: 0.06, rh: 0.11 },
        { rx: 0.19, rw: 0.08, rh: 0.14 },
        { rx: 0.38, rw: 0.1, rh: 0.18 },
      ];
      structures.forEach((s) => {
        const sx = vanishX + s.rx * w;
        const sw = s.rw * w;
        const sh = s.rh * h;
        const sy = horizonY - sh * 0.55;
        ctx.fillStyle = '#0c111a';
        ctx.strokeStyle = 'rgba(148, 163, 184, 0.14)';
        ctx.lineWidth = 1;
        ctx.fillRect(sx - sw / 2, sy, sw, sh);
        ctx.strokeRect(sx - sw / 2, sy, sw, sh);
      });
    };

    const renderFrame = (now: number) => {
      const dt = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;
      const t = now / 1000;

      const w = window.innerWidth;
      const h = window.innerHeight;
      const cfg = configRef.current;
      const cx = w * 0.5;
      const cy = h * 0.5;

      if (!lockCursorRef.current.initialized) {
        lockCursorRef.current = { x: cx, y: cy, initialized: true };
      }

      const panX = aimOffsetRef.current.x;
      const panY = aimOffsetRef.current.y;

      drawArenaBackground(w, h, t, panX, panY);

      const horizonY = h * 0.48 + panY * 0.35;
      const vanishX = w * 0.5 + panX * 0.5;

      // Update & draw simulated enemy targets
      let bestTarget: { x: number; y: number; dist: number; name: string } | null = null;

      // Sort far to near
      const projected = enemies
        .map((enemy) => {
          const strafe = Math.sin(t * enemy.speed + enemy.phase) * 0.24;
          const depthOsc = Math.cos(t * enemy.speed * 0.6 + enemy.phase) * 0.06;
          const depth = Math.max(0.32, Math.min(0.95, enemy.depth + depthOsc));

          // Simulate subtle HP fluctuation when ESP/Aimbot active
          if (cfg.aimbotEnabled && Math.random() < 0.015) {
            enemy.hp = enemy.hp <= 15 ? 100 : Math.max(12, enemy.hp - Math.floor(Math.random() * 14));
          } else if (enemy.hp < 100 && Math.random() < 0.01) {
            enemy.hp = Math.min(100, enemy.hp + 4);
          }

          const worldX = enemy.baseX + strafe;
          const scale = 1.25 - depth * 0.85; // closer = bigger
          const screenX = vanishX + worldX * (w * 0.55) * (1.1 - depth * 0.35);
          const footY = horizonY + (1 - depth * 0.72) * (h * 0.34);
          const boxH = Math.max(54, 175 * scale);
          const boxW = boxH * 0.48;
          const topY = footY - boxH;
          const distMeters = Math.round(depth * 78 + 8);

          return {
            enemy,
            screenX,
            topY,
            footY,
            boxW,
            boxH,
            distMeters,
          };
        })
        .sort((a, b) => b.enemy.depth - a.enemy.depth);

      for (const { enemy, screenX, topY, footY, boxW, boxH, distMeters } of projected) {
        const left = screenX - boxW / 2;
        const headY = topY + boxH * 0.14;
        const neckY = topY + boxH * 0.24;
        const chestY = topY + boxH * 0.38;
        const pelvisY = topY + boxH * 0.56;

        // Draw stylized tactical enemy figure
        ctx.save();
        ctx.fillStyle = 'rgba(203, 213, 225, 0.22)';
        ctx.strokeStyle = 'rgba(226, 232, 240, 0.42)';
        ctx.lineWidth = 1.4;

        // Head
        const headR = Math.max(5, boxW * 0.16);
        ctx.beginPath();
        ctx.arc(screenX, headY, headR, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Torso
        ctx.beginPath();
        ctx.roundRect(screenX - boxW * 0.24, neckY, boxW * 0.48, boxH * 0.34, 4);
        ctx.fill();
        ctx.stroke();

        // Legs (animated stride)
        const stride = Math.sin(t * enemy.speed * 4 + enemy.phase) * (boxW * 0.14);
        ctx.beginPath();
        ctx.moveTo(screenX - boxW * 0.12, pelvisY);
        ctx.lineTo(screenX - boxW * 0.16 + stride, footY);
        ctx.moveTo(screenX + boxW * 0.12, pelvisY);
        ctx.lineTo(screenX + boxW * 0.16 - stride, footY);
        ctx.lineWidth = Math.max(2, boxW * 0.11);
        ctx.strokeStyle = 'rgba(148, 163, 184, 0.36)';
        ctx.stroke();
        ctx.restore();

        // Check Aimbot FOV candidacy
        const aimY =
          cfg.aimbotBone === 'head' ? headY : cfg.aimbotBone === 'neck' ? neckY : chestY;
        const dx = screenX - cx;
        const dy = aimY - cy;
        const distFromCenter = Math.hypot(dx, dy);
        if (cfg.aimbotEnabled && distFromCenter <= cfg.aimbotFov) {
          if (!bestTarget || distFromCenter < bestTarget.dist) {
            bestTarget = { x: screenX, y: aimY, dist: distFromCenter, name: enemy.name };
          }
        }

        // ESP Overlay rendering
        if (cfg.espEnabled) {
          const isLocked = bestTarget !== null && bestTarget.name === enemy.name && cfg.aimbotEnabled;
          const espPrimary = isLocked ? '#00f0ff' : '#ff1e42';

          // Snaplines
          if (cfg.espSnaplines) {
            ctx.strokeStyle = isLocked ? 'rgba(0, 240, 255, 0.7)' : 'rgba(255, 30, 66, 0.45)';
            ctx.lineWidth = isLocked ? 1.5 : 1;
            ctx.beginPath();
            ctx.moveTo(cx, 54);
            ctx.lineTo(screenX, topY);
            ctx.stroke();
          }

          // Cornered ESP Hitbox
          if (cfg.espBoxes) {
            const corner = Math.max(8, boxW * 0.28);
            ctx.strokeStyle = espPrimary;
            ctx.lineWidth = isLocked ? 2 : 1.5;
            ctx.shadowColor = espPrimary;
            ctx.shadowBlur = isLocked ? 10 : 4;

            ctx.beginPath();
            // Top-Left
            ctx.moveTo(left, topY + corner);
            ctx.lineTo(left, topY);
            ctx.lineTo(left + corner, topY);
            // Top-Right
            ctx.moveTo(left + boxW - corner, topY);
            ctx.lineTo(left + boxW, topY);
            ctx.lineTo(left + boxW, topY + corner);
            // Bottom-Right
            ctx.moveTo(left + boxW, footY - corner);
            ctx.lineTo(left + boxW, footY);
            ctx.lineTo(left + boxW - corner, footY);
            // Bottom-Left
            ctx.moveTo(left + corner, footY);
            ctx.lineTo(left, footY);
            ctx.lineTo(left, footY - corner);
            ctx.stroke();
            ctx.shadowBlur = 0;
          }

          // Skeleton & Headbone indicator
          if (cfg.espSkeleton) {
            ctx.strokeStyle = 'rgba(0, 240, 255, 0.8)';
            ctx.lineWidth = 1.25;
            ctx.beginPath();
            ctx.moveTo(screenX, headY);
            ctx.lineTo(screenX, pelvisY);
            ctx.moveTo(screenX - boxW * 0.26, neckY + 4);
            ctx.lineTo(screenX + boxW * 0.26, neckY + 4);
            ctx.stroke();

            ctx.fillStyle = '#00f0ff';
            ctx.beginPath();
            ctx.arc(screenX, headY, 2.8, 0, Math.PI * 2);
            ctx.fill();
          }

          // Health Bar + Player Name & Distance Tag
          if (cfg.espHealthBar) {
            const hpRatio = enemy.hp / enemy.maxHp;
            const barW = 4;
            const barX = left - 8;
            ctx.fillStyle = 'rgba(8, 10, 14, 0.85)';
            ctx.fillRect(barX - 1, topY - 1, barW + 2, boxH + 2);

            const hpColor = hpRatio > 0.6 ? '#10b981' : hpRatio > 0.3 ? '#f59e0b' : '#ff1e42';
            const fillH = boxH * hpRatio;
            ctx.fillStyle = hpColor;
            ctx.fillRect(barX, footY - fillH, barW, fillH);

            // Player label
            const label = `${enemy.name} · ${distMeters}m`;
            ctx.font = '600 11px "JetBrains Mono", monospace';
            const tw = ctx.measureText(label).width;
            ctx.fillStyle = 'rgba(7, 9, 13, 0.82)';
            ctx.fillRect(screenX - tw / 2 - 5, topY - 21, tw + 10, 16);
            ctx.fillStyle = isLocked ? '#00f0ff' : '#f8fafc';
            ctx.textAlign = 'center';
            ctx.fillText(label, screenX, topY - 9);
          }
        }
      }

      // Aimbot FOV Circle & Smooth Tracking Indicator
      if (cfg.aimbotEnabled) {
        const hasTarget = bestTarget !== null;
        ctx.save();
        ctx.beginPath();
        ctx.arc(cx, cy, cfg.aimbotFov, 0, Math.PI * 2);
        ctx.strokeStyle = hasTarget ? 'rgba(255, 30, 66, 0.85)' : 'rgba(0, 240, 255, 0.55)';
        ctx.lineWidth = hasTarget ? 1.8 : 1.3;
        ctx.shadowColor = hasTarget ? '#ff1e42' : '#00f0ff';
        ctx.shadowBlur = hasTarget ? 14 : 8;
        ctx.stroke();
        ctx.shadowBlur = 0;

        // Subtle segmented tick marks on FOV ring
        for (let a = 0; a < 4; a++) {
          const ang = (a * Math.PI) / 2;
          ctx.beginPath();
          ctx.moveTo(cx + Math.cos(ang) * (cfg.aimbotFov - 5), cy + Math.sin(ang) * (cfg.aimbotFov - 5));
          ctx.lineTo(cx + Math.cos(ang) * (cfg.aimbotFov + 5), cy + Math.sin(ang) * (cfg.aimbotFov + 5));
          ctx.strokeStyle = hasTarget ? '#ff1e42' : '#00f0ff';
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }

        // Smooth lock cursor interpolation
        const targetX = bestTarget ? bestTarget.x : cx;
        const targetY = bestTarget ? bestTarget.y : cy;
        const lerpRate = Math.min(1, (22 - cfg.aimbotSmoothness) * dt * 0.9);
        lockCursorRef.current.x += (targetX - lockCursorRef.current.x) * lerpRate;
        lockCursorRef.current.y += (targetY - lockCursorRef.current.y) * lerpRate;

        if (bestTarget) {
          ctx.strokeStyle = 'rgba(0, 240, 255, 0.65)';
          ctx.setLineDash([4, 4]);
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.moveTo(cx, cy);
          ctx.lineTo(lockCursorRef.current.x, lockCursorRef.current.y);
          ctx.stroke();
          ctx.setLineDash([]);

          // Target lock diamond
          const lx = lockCursorRef.current.x;
          const ly = lockCursorRef.current.y;
          ctx.strokeStyle = '#ff1e42';
          ctx.lineWidth = 1.6;
          ctx.beginPath();
          ctx.moveTo(lx, ly - 8);
          ctx.lineTo(lx + 8, ly);
          ctx.lineTo(lx, ly + 8);
          ctx.lineTo(lx - 8, ly);
          ctx.closePath();
          ctx.stroke();

          ctx.font = '600 10px "JetBrains Mono", monospace';
          ctx.fillStyle = '#00f0ff';
          ctx.textAlign = 'left';
          ctx.fillText(
            `LOCK: ${bestTarget.name} (${cfg.aimbotBone.toUpperCase()})`,
            cx + cfg.aimbotFov * 0.55,
            cy + cfg.aimbotFov + 16
          );
        }
        ctx.restore();
      }

      // Custom Pro Crosshair
      if (cfg.crosshairEnabled) {
        const colorMap = {
          cyan: '#00f0ff',
          crimson: '#ff1e42',
          emerald: '#10b981',
        };
        const c = colorMap[cfg.crosshairColor];
        ctx.save();
        ctx.strokeStyle = c;
        ctx.fillStyle = c;
        ctx.lineWidth = 1.8;
        ctx.shadowColor = c;
        ctx.shadowBlur = 6;

        if (cfg.crosshairStyle === 'pro-t') {
          const gap = 5;
          const len = 10;
          ctx.beginPath();
          // Left, Right, Bottom (T-style open top for clear headshot view)
          ctx.moveTo(cx - gap - len, cy);
          ctx.lineTo(cx - gap, cy);
          ctx.moveTo(cx + gap, cy);
          ctx.lineTo(cx + gap + len, cy);
          ctx.moveTo(cx, cy + gap);
          ctx.lineTo(cx, cy + gap + len);
          ctx.stroke();
          ctx.beginPath();
          ctx.arc(cx, cy, 1.8, 0, Math.PI * 2);
          ctx.fill();
        } else if (cfg.crosshairStyle === 'cyber-dot') {
          ctx.beginPath();
          ctx.arc(cx, cy, 2.4, 0, Math.PI * 2);
          ctx.fill();
          ctx.beginPath();
          ctx.arc(cx, cy, 9, 0, Math.PI * 2);
          ctx.lineWidth = 1.2;
          ctx.stroke();
        } else {
          // Dynamic X
          const g = 5;
          const l = 9;
          ctx.beginPath();
          ctx.moveTo(cx - g - l, cy - g - l);
          ctx.lineTo(cx - g, cy - g);
          ctx.moveTo(cx + g + l, cy - g - l);
          ctx.lineTo(cx + g, cy - g);
          ctx.moveTo(cx - g - l, cy + g + l);
          ctx.lineTo(cx - g, cy + g);
          ctx.moveTo(cx + g + l, cy + g + l);
          ctx.lineTo(cx + g, cy + g);
          ctx.stroke();
          ctx.beginPath();
          ctx.arc(cx, cy, 1.6, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }

      // Subtle arena watermark / interactive hint in bottom-left
      ctx.save();
      ctx.font = '500 11px "JetBrains Mono", monospace';
      ctx.fillStyle = 'rgba(148, 163, 184, 0.45)';
      ctx.textAlign = 'left';
      ctx.fillText(
        `ARENA SIM · DRAG CANVAS TO AIM PAN · HOOK: ${bypassRef.current ? 'PATCHED' : 'STANDBY'}`,
        16,
        h - 16
      );
      ctx.restore();

      animId = requestAnimationFrame(renderFrame);
    };

    animId = requestAnimationFrame(renderFrame);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    dragRef.current = { active: true, lastX: e.clientX, lastY: e.clientY };
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!dragRef.current.active) return;
    const dx = e.clientX - dragRef.current.lastX;
    const dy = e.clientY - dragRef.current.lastY;
    dragRef.current.lastX = e.clientX;
    dragRef.current.lastY = e.clientY;
    aimOffsetRef.current.x = Math.max(-240, Math.min(240, aimOffsetRef.current.x + dx));
    aimOffsetRef.current.y = Math.max(-120, Math.min(120, aimOffsetRef.current.y + dy));
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    dragRef.current.active = false;
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
  };

  return (
    <canvas
      ref={canvasRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      className="fixed inset-0 w-full h-full touch-none cursor-crosshair select-none"
      aria-label="Live Tactical Arena Simulation Viewport"
    />
  );
};
