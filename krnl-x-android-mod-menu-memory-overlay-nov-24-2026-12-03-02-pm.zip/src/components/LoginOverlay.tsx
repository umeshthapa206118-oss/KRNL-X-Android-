import React, { useState } from 'react';
import { KeyRound, ShieldAlert, Sparkles, Unlock } from 'lucide-react';

interface LoginOverlayProps {
  onUnlock: (licenseKey: string) => void;
}

const VALID_KEY_PATTERN = /^KRNL-VIP-[A-Z0-9]{4}-ARM64$/;

export const LoginOverlay: React.FC<LoginOverlayProps> = ({ onUnlock }) => {
  const [keyInput, setKeyInput] = useState('');
  const [error, setError] = useState('');
  const [justGenerated, setJustGenerated] = useState(false);

  const handleGetKey = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let token = '';
    for (let i = 0; i < 4; i++) {
      token += chars[Math.floor(Math.random() * chars.length)];
    }
    const generated = `KRNL-VIP-${token}-ARM64`;
    setKeyInput(generated);
    setError('');
    setJustGenerated(true);
    setTimeout(() => setJustGenerated(false), 1800);
  };

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = keyInput.trim().toUpperCase();
    if (!cleaned) {
      setError('Enter a VIP activation key or tap GET KEY to auto-fill.');
      return;
    }
    if (!VALID_KEY_PATTERN.test(cleaned) && cleaned !== 'VIP-2026' && cleaned !== 'DEMO') {
      setError('Invalid key format. Expected KRNL-VIP-XXXX-ARM64.');
      return;
    }
    setError('');
    onUnlock(cleaned);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#05070b]/85 backdrop-blur-md">
      <div className="w-full max-w-md rounded-2xl bg-[#0b0e14]/95 border border-white/12 shadow-[0_24px_80px_rgba(0,0,0,0.85),0_0_40px_rgba(255,30,66,0.12)] p-6 sm:p-7">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 mb-6">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
              KRNL-X VIP Overlay
            </h1>
            <p className="mt-1.5 text-xs font-mono text-slate-400">
              Android ARM64-v8a · ImGui Overlay · Memory Utility
            </p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-[#ff1e42]/12 border border-[#ff1e42]/35 flex items-center justify-center shrink-0">
            <KeyRound className="w-5 h-5 text-[#ff1e42]" />
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleVerify} className="space-y-4">
          <div>
            <label htmlFor="vip-key-input" className="block text-xs font-medium text-slate-300 mb-2">
              Activation License Key
            </label>
            <div className="flex flex-col sm:flex-row gap-2.5">
              <input
                id="vip-key-input"
                type="text"
                value={keyInput}
                onChange={(e) => {
                  setKeyInput(e.target.value);
                  if (error) setError('');
                }}
                placeholder="KRNL-VIP-XXXX-ARM64"
                autoComplete="off"
                spellCheck={false}
                className="flex-1 min-h-[46px] px-3.5 rounded-xl bg-[#07090d] border border-white/12 focus:border-[#00f0ff] focus:outline-none font-mono text-sm text-white placeholder:text-slate-600 transition-colors"
              />
              <button
                type="button"
                onClick={handleGetKey}
                className="min-h-[46px] px-4 rounded-xl bg-[#00f0ff]/12 hover:bg-[#00f0ff]/20 border border-[#00f0ff]/45 text-[#00f0ff] text-xs font-semibold tracking-wide flex items-center justify-center gap-1.5 transition-all active:scale-[0.98] whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{justGenerated ? 'KEY FILLED' : 'GET KEY'}</span>
              </button>
            </div>
          </div>

          {error && (
            <div
              role="alert"
              className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#ff1e42]/12 border border-[#ff1e42]/35 text-xs text-[#ff6b81]"
            >
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            className="w-full min-h-[48px] px-5 rounded-xl bg-[#ff1e42] hover:bg-[#ff3355] text-white text-sm font-semibold tracking-wide flex items-center justify-center gap-2 shadow-[0_0_24px_rgba(255,30,66,0.4)] transition-all active:scale-[0.98] cursor-pointer"
          >
            <Unlock className="w-4 h-4" />
            <span>VERIFY &amp; UNLOCK MENU</span>
          </button>
        </form>

        {/* Clean footer metadata */}
        <div className="mt-5 pt-4 border-t border-white/8 flex items-center justify-between text-xs text-slate-400 font-mono">
          <span>Target: libil2cpp.so</span>
          <span>Root / No-Root Virtual</span>
        </div>
      </div>
    </div>
  );
};
