import React, { useEffect, useState } from 'react';
import { Code2, ShieldCheck } from 'lucide-react';
import { ModConfig } from '../types/modMenu';

interface FpsHudProps {
  config: ModConfig;
  bypassActive: boolean;
  unlocked: boolean;
  onOpenExport: () => void;
}

export const FpsHud: React.FC<FpsHudProps> = ({ config, bypassActive, unlocked, onOpenExport }) => {
  const [metrics, setMetrics] = useState({ fps: 60, ping: 64, frameMs: 16.6 });

  useEffect(() => {
    const update = () => {
      if (config.fpsBoosterEnabled) {
        const fps = 117 + Math.floor(Math.random() * 4);
        const ping = config.antiLagEnabled
          ? 12 + Math.floor(Math.random() * 5)
          : 44 + Math.floor(Math.random() * 14);
        setMetrics({
          fps,
          ping,
          frameMs: Number((1000 / fps).toFixed(1)),
        });
      } else {
        const fps = 56 + Math.floor(Math.random() * 5);
        const ping = config.antiLagEnabled
          ? 24 + Math.floor(Math.random() * 6)
          : 62 + Math.floor(Math.random() * 18);
        setMetrics({
          fps,
          ping,
          frameMs: Number((1000 / fps).toFixed(1)),
        });
      }
    };

    update();
    const id = setInterval(update, 650);
    return () => clearInterval(id);
  }, [config.fpsBoosterEnabled, config.antiLagEnabled]);

  return (
    <header className="fixed top-3 left-3 right-3 z-30 flex items-center justify-between gap-4 pointer-events-none">
      {/* Live FPS & Ping HUD (shown prominently when 120 FPS / Booster active, or subtle baseline) */}
      <div
        className={`pointer-events-auto flex items-center gap-3 px-3.5 py-2 rounded-xl border backdrop-blur-md transition-all duration-200 ${
          config.fpsBoosterEnabled
            ? 'bg-[#0a0c10]/85 border-[#00f0ff]/40 shadow-[0_0_20px_rgba(0,240,255,0.14)]'
            : 'bg-[#0a0c10]/70 border-white/10'
        }`}
      >
        <div className="flex items-center gap-2 font-mono text-xs sm:text-sm tabular-nums whitespace-nowrap">
          <span className={config.fpsBoosterEnabled ? 'text-[#00f0ff] font-semibold' : 'text-slate-200 font-semibold'}>
            {metrics.fps} FPS
          </span>
          <span className="text-slate-600" aria-hidden="true">·</span>
          <span className={config.antiLagEnabled ? 'text-emerald-400' : 'text-amber-400'}>
            {metrics.ping} ms
          </span>
          <span className="hidden sm:inline text-slate-600" aria-hidden="true">·</span>
          <span className="hidden sm:inline text-slate-400 text-xs">{metrics.frameMs} ms/f</span>
        </div>

        {bypassActive && (
          <div className="hidden md:flex items-center gap-1.5 pl-2.5 border-l border-white/10 text-xs font-mono text-emerald-400 whitespace-nowrap">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>ARM64 HOOKED</span>
          </div>
        )}
      </div>

      {/* Single primary utility action: Export / View Single-File HTML */}
      {unlocked && (
        <button
          type="button"
          onClick={onOpenExport}
          className="pointer-events-auto min-h-[40px] px-3.5 py-2 rounded-xl bg-[#0a0c10]/85 hover:bg-[#131722] border border-white/15 hover:border-[#00f0ff]/50 text-xs font-medium text-slate-100 flex items-center gap-2 backdrop-blur-md transition-all active:scale-[0.98] whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Code2 className="w-4 h-4 text-[#00f0ff]" />
          <span>Single-File HTML</span>
        </button>
      )}
    </header>
  );
};
