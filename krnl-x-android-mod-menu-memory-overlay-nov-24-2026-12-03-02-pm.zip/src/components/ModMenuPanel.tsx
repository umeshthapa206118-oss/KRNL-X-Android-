import React, { useEffect, useRef, useState } from 'react';
import {
  Crosshair,
  Cpu,
  Eye,
  GripHorizontal,
  Minimize2,
  Play,
  RotateCcw,
  Terminal,
  Trash2,
} from 'lucide-react';
import {
  AimBone,
  CrosshairColor,
  CrosshairStyle,
  MenuTab,
  ModConfig,
  TerminalLogLine,
} from '../types/modMenu';

interface ModMenuPanelProps {
  isOpen: boolean;
  licenseKey: string;
  config: ModConfig;
  bypassActive: boolean;
  isInjecting: boolean;
  logs: TerminalLogLine[];
  onChangeConfig: (updater: (prev: ModConfig) => ModConfig) => void;
  onResetConfig: () => void;
  onMinimize: () => void;
  onInjectBypass: () => void;
  onClearLogs: () => void;
}

interface ToggleRowProps {
  label: string;
  description: string;
  checked: boolean;
  accent?: 'cyan' | 'crimson';
  onChange: (next: boolean) => void;
}

const ToggleRow: React.FC<ToggleRowProps> = ({
  label,
  description,
  checked,
  accent = 'cyan',
  onChange,
}) => {
  const activeBg =
    accent === 'crimson'
      ? 'bg-[#ff1e42] shadow-[0_0_12px_rgba(255,30,66,0.65)]'
      : 'bg-[#00f0ff] shadow-[0_0_12px_rgba(0,240,255,0.6)]';

  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="w-full min-h-[48px] px-3 py-2.5 rounded-xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.07] flex items-center justify-between gap-3 text-left transition-colors cursor-pointer"
    >
      <div className="min-w-0">
        <div className="text-sm font-medium text-slate-100 truncate">{label}</div>
        <div className="text-[11px] text-slate-400 truncate">{description}</div>
      </div>
      <div
        className={`w-11 h-6 rounded-full p-0.5 transition-colors duration-200 shrink-0 flex items-center ${
          checked ? activeBg : 'bg-slate-800 border border-white/10'
        }`}
      >
        <div
          className={`w-5 h-5 rounded-full bg-white shadow-sm transition-transform duration-200 ${
            checked ? 'translate-x-5' : 'translate-x-0'
          }`}
        />
      </div>
    </button>
  );
};

export const ModMenuPanel: React.FC<ModMenuPanelProps> = ({
  isOpen,
  licenseKey,
  config,
  bypassActive,
  isInjecting,
  logs,
  onChangeConfig,
  onResetConfig,
  onMinimize,
  onInjectBypass,
  onClearLogs,
}) => {
  const [activeTab, setActiveTab] = useState<MenuTab>('esp');
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const dragRef = useRef<{
    active: boolean;
    pointerId: number | null;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
  }>({
    active: false,
    pointerId: null,
    startX: 0,
    startY: 0,
    origX: 0,
    origY: 0,
  });

  const terminalEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [logs]);

  if (!isOpen) return null;

  const handleHeaderDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if ((e.target as HTMLElement).closest('button')) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    dragRef.current = {
      active: true,
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      origX: offset.x,
      origY: offset.y,
    };
  };

  const handleHeaderMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragRef.current.active || dragRef.current.pointerId !== e.pointerId) return;
    const dx = e.clientX - dragRef.current.startX;
    const dy = e.clientY - dragRef.current.startY;
    const maxX = Math.max(40, window.innerWidth * 0.35);
    const maxY = Math.max(40, window.innerHeight * 0.3);
    setOffset({
      x: Math.min(Math.max(-maxX, dragRef.current.origX + dx), maxX),
      y: Math.min(Math.max(-maxY, dragRef.current.origY + dy), maxY),
    });
  };

  const handleHeaderUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragRef.current.active || dragRef.current.pointerId !== e.pointerId) return;
    dragRef.current.active = false;
    dragRef.current.pointerId = null;
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
  };

  const logLevelColor = (level: TerminalLogLine['level']) => {
    switch (level) {
      case 'cmd':
        return 'text-[#00f0ff] font-semibold';
      case 'mem':
        return 'text-amber-300';
      case 'warn':
        return 'text-[#ff6b81]';
      case 'success':
        return 'text-emerald-400 font-semibold';
      default:
        return 'text-slate-300';
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-3 sm:p-6 pointer-events-none">
      <section
        aria-label="ImGui Mod Menu Overlay"
        style={{
          transform: `translate3d(${offset.x}px, ${offset.y}px, 0)`,
        }}
        className="pointer-events-auto w-full max-w-[430px] max-h-[86vh] flex flex-col rounded-2xl bg-[#0a0c10]/90 backdrop-blur-xl border border-white/15 shadow-[0_24px_80px_rgba(0,0,0,0.85),0_0_32px_rgba(0,240,255,0.12)] overflow-hidden"
      >
        {/* Top Glowing Accent Bar */}
        <div className="h-[2px] w-full bg-gradient-to-r from-[#ff1e42] via-[#00f0ff] to-[#ff1e42]" />

        {/* Draggable ImGui Title Header */}
        <div
          onPointerDown={handleHeaderDown}
          onPointerMove={handleHeaderMove}
          onPointerUp={handleHeaderUp}
          onPointerCancel={handleHeaderUp}
          className="px-4 py-3 bg-white/[0.03] border-b border-white/10 flex items-center justify-between gap-3 touch-none select-none cursor-grab active:cursor-grabbing"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <GripHorizontal className="w-4 h-4 text-slate-500 shrink-0" />
            <div className="min-w-0">
              <div className="text-sm font-bold tracking-wide text-white truncate">
                KRNL-X MOD MENU
              </div>
              <div className="text-[11px] font-mono text-slate-400 truncate">
                {licenseKey} · {bypassActive ? 'BYPASS ACTIVE' : 'HOOK STANDBY'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={onResetConfig}
              title="Reset Mod Settings"
              aria-label="Reset Mod Settings"
              className="w-10 h-10 rounded-lg bg-white/[0.04] hover:bg-white/[0.09] border border-white/10 flex items-center justify-center text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onMinimize}
              title="Collapse to Floating Bubble"
              aria-label="Collapse to Floating Bubble"
              className="w-10 h-10 rounded-lg bg-[#ff1e42]/15 hover:bg-[#ff1e42]/25 border border-[#ff1e42]/40 flex items-center justify-center text-[#ff6b81] hover:text-white transition-colors cursor-pointer"
            >
              <Minimize2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Segmented Tab Bar */}
        <div className="p-2 bg-[#07090d]/70 border-b border-white/10 grid grid-cols-3 gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('esp')}
            className={`min-h-[42px] px-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'esp'
                ? 'bg-[#00f0ff]/15 text-[#00f0ff] border border-[#00f0ff]/45 shadow-[0_0_16px_rgba(0,240,255,0.16)]'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.04] border border-transparent'
            }`}
          >
            <Eye className="w-3.5 h-3.5 shrink-0" />
            <span>ESP Visuals</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('aim')}
            className={`min-h-[42px] px-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'aim'
                ? 'bg-[#ff1e42]/18 text-[#ff6b81] border border-[#ff1e42]/50 shadow-[0_0_16px_rgba(255,30,66,0.18)]'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.04] border border-transparent'
            }`}
          >
            <Crosshair className="w-3.5 h-3.5 shrink-0" />
            <span>Aim &amp; FOV</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('system')}
            className={`min-h-[42px] px-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'system'
                ? 'bg-[#00f0ff]/15 text-[#00f0ff] border border-[#00f0ff]/45 shadow-[0_0_16px_rgba(0,240,255,0.16)]'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.04] border border-transparent'
            }`}
          >
            <Cpu className="w-3.5 h-3.5 shrink-0" />
            <span>120 FPS</span>
          </button>
        </div>

        {/* Scrollable Mod Controls Area */}
        <div className="flex-1 overflow-y-auto cyber-scroll p-3.5 space-y-2.5 min-h-[180px]">
          {activeTab === 'esp' && (
            <>
              <ToggleRow
                label="Master ESP Overlay"
                description="Draw live enemy hitboxes & player info"
                checked={config.espEnabled}
                accent="crimson"
                onChange={(v) => onChangeConfig((p) => ({ ...p, espEnabled: v }))}
              />
              <ToggleRow
                label="2D Corner Hitboxes"
                description="Render glowing enemy bounding boxes"
                checked={config.espBoxes}
                onChange={(v) => onChangeConfig((p) => ({ ...p, espBoxes: v }))}
              />
              <ToggleRow
                label="Player Health & Distance"
                description="Show live HP bar, alias & meter distance"
                checked={config.espHealthBar}
                onChange={(v) => onChangeConfig((p) => ({ ...p, espHealthBar: v }))}
              />
              <ToggleRow
                label="Snaplines & Head Skeleton"
                description="Draw bone axis and top-center tracers"
                checked={config.espSnaplines && config.espSkeleton}
                onChange={(v) =>
                  onChangeConfig((p) => ({ ...p, espSnaplines: v, espSkeleton: v }))
                }
              />
            </>
          )}

          {activeTab === 'aim' && (
            <>
              <ToggleRow
                label="Aimbot & FOV Lock"
                description="Enable center FOV circle & smooth tracking"
                checked={config.aimbotEnabled}
                accent="crimson"
                onChange={(v) => onChangeConfig((p) => ({ ...p, aimbotEnabled: v }))}
              />

              {/* FOV Slider */}
              <div className="px-3 py-2.5 rounded-xl bg-white/[0.03] border border-white/[0.07]">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-medium text-slate-200">FOV Circle Radius</span>
                  <span className="font-mono text-[#00f0ff] font-semibold">
                    {config.aimbotFov} px
                  </span>
                </div>
                <input
                  type="range"
                  min={40}
                  max={220}
                  step={2}
                  value={config.aimbotFov}
                  onChange={(e) =>
                    onChangeConfig((p) => ({ ...p, aimbotFov: Number(e.target.value) }))
                  }
                  className="cyber-slider"
                  aria-label="Aimbot FOV Circle Radius"
                />
              </div>

              {/* Smoothness Slider */}
              <div className="px-3 py-2.5 rounded-xl bg-white/[0.03] border border-white/[0.07]">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-medium text-slate-200">Aimbot Smoothness</span>
                  <span className="font-mono text-[#ff6b81] font-semibold">
                    {config.aimbotSmoothness.toFixed(1)}x
                  </span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={20}
                  step={0.5}
                  value={config.aimbotSmoothness}
                  onChange={(e) =>
                    onChangeConfig((p) => ({ ...p, aimbotSmoothness: Number(e.target.value) }))
                  }
                  className="cyber-slider crimson"
                  aria-label="Aimbot Smoothness"
                />
              </div>

              {/* Target Bone Selector */}
              <div className="px-3 py-2.5 rounded-xl bg-white/[0.03] border border-white/[0.07]">
                <div className="text-xs font-medium text-slate-200 mb-2">Target Hitbox Bone</div>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['head', 'neck', 'chest'] as AimBone[]).map((bone) => (
                    <button
                      key={bone}
                      type="button"
                      onClick={() => onChangeConfig((p) => ({ ...p, aimbotBone: bone }))}
                      className={`min-h-[38px] rounded-lg text-xs font-mono uppercase transition-colors cursor-pointer ${
                        config.aimbotBone === bone
                          ? 'bg-[#ff1e42] text-white font-semibold'
                          : 'bg-[#07090d] text-slate-400 hover:text-white border border-white/10'
                      }`}
                    >
                      {bone}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Pro Crosshair */}
              <ToggleRow
                label="Custom Pro Crosshair"
                description="Render sharp center-screen tactical reticle"
                checked={config.crosshairEnabled}
                onChange={(v) => onChangeConfig((p) => ({ ...p, crosshairEnabled: v }))}
              />

              {config.crosshairEnabled && (
                <div className="px-3 py-2.5 rounded-xl bg-white/[0.03] border border-white/[0.07] space-y-2.5">
                  <div className="grid grid-cols-3 gap-1.5">
                    {(
                      [
                        { id: 'pro-t', label: 'Pro T' },
                        { id: 'cyber-dot', label: 'Cyber Dot' },
                        { id: 'dynamic-x', label: 'Dynamic X' },
                      ] as { id: CrosshairStyle; label: string }[]
                    ).map((st) => (
                      <button
                        key={st.id}
                        type="button"
                        onClick={() => onChangeConfig((p) => ({ ...p, crosshairStyle: st.id }))}
                        className={`min-h-[36px] rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                          config.crosshairStyle === st.id
                            ? 'bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/50'
                            : 'bg-[#07090d] text-slate-400 hover:text-white border border-white/10'
                        }`}
                      >
                        {st.label}
                      </button>
                    ))}
                  </div>
                  <div className="grid grid-cols-3 gap-1.5">
                    {(['cyan', 'crimson', 'emerald'] as CrosshairColor[]).map((col) => (
                      <button
                        key={col}
                        type="button"
                        onClick={() => onChangeConfig((p) => ({ ...p, crosshairColor: col }))}
                        className={`min-h-[34px] rounded-lg text-[11px] font-mono uppercase transition-colors cursor-pointer ${
                          config.crosshairColor === col
                            ? 'bg-white/15 text-white border border-white/40'
                            : 'bg-[#07090d] text-slate-400 hover:text-white border border-white/10'
                        }`}
                      >
                        {col}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}

          {activeTab === 'system' && (
            <>
              <ToggleRow
                label="120 FPS Frame Unlocker"
                description="Override Unity frame pacing & show live HUD"
                checked={config.fpsBoosterEnabled}
                onChange={(v) => onChangeConfig((p) => ({ ...p, fpsBoosterEnabled: v }))}
              />
              <ToggleRow
                label="Anti-Lag Network Optimizer"
                description="TCP_NODELAY & UDP jitter buffer clamp"
                checked={config.antiLagEnabled}
                onChange={(v) => onChangeConfig((p) => ({ ...p, antiLagEnabled: v }))}
              />
              <ToggleRow
                label="Stream-Proof Anti-Screenshot"
                description="FLAG_SECURE surface mask simulation"
                checked={config.stealthAntiScreenshot}
                accent="crimson"
                onChange={(v) =>
                  onChangeConfig((p) => ({ ...p, stealthAntiScreenshot: v }))
                }
              />
            </>
          )}
        </div>

        {/* Bottom Python & Memory Injection Terminal */}
        <div className="border-t border-white/12 bg-[#06080c]/95 p-3 space-y-2.5 shrink-0">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-[11px] font-mono text-slate-300">
              <Terminal className="w-3.5 h-3.5 text-[#00f0ff]" />
              <span>python3 · pymem / frida console</span>
            </div>
            <button
              type="button"
              onClick={onClearLogs}
              aria-label="Clear terminal logs"
              className="px-2 py-1 rounded text-[11px] font-mono text-slate-400 hover:text-white hover:bg-white/5 flex items-center gap-1 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3 h-3" />
              <span>Clear</span>
            </button>
          </div>

          {/* Auto-scrolling Terminal Log Box */}
          <div
            className="h-32 overflow-y-auto cyber-scroll rounded-xl bg-[#040508] border border-white/10 p-2.5 font-mono text-[11px] leading-relaxed space-y-1"
            aria-live="polite"
          >
            {logs.length === 0 ? (
              <div className="text-slate-600">
                Ready. Tap INJECT PYTHON BYPASS to attach frida-gadget &amp; scan libil2cpp.so.
              </div>
            ) : (
              logs.map((entry) => (
                <div key={entry.id} className="break-words">
                  <span className="text-slate-600 mr-1.5">[{entry.time}]</span>
                  <span className={logLevelColor(entry.level)}>{entry.text}</span>
                </div>
              ))
            )}
            <div ref={terminalEndRef} />
          </div>

          {/* Primary Injection Action Button */}
          <button
            type="button"
            disabled={isInjecting}
            onClick={onInjectBypass}
            className={`w-full min-h-[46px] px-4 rounded-xl text-xs font-bold tracking-wider flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer ${
              isInjecting
                ? 'bg-amber-500/20 border border-amber-400/40 text-amber-300 cursor-wait'
                : bypassActive
                ? 'bg-emerald-500/18 hover:bg-emerald-500/28 border border-emerald-400/50 text-emerald-300 shadow-[0_0_20px_rgba(16,185,129,0.2)]'
                : 'bg-gradient-to-r from-[#ff1e42] to-[#d91436] hover:from-[#ff2e50] hover:to-[#eb1c40] text-white shadow-[0_0_24px_rgba(255,30,66,0.4)]'
            }`}
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>
              {isInjecting
                ? 'INJECTING HOOKS...'
                : bypassActive
                ? 'RE-INJECT PYTHON BYPASS'
                : 'INJECT PYTHON BYPASS'}
            </span>
          </button>
        </div>
      </section>
    </div>
  );
};
